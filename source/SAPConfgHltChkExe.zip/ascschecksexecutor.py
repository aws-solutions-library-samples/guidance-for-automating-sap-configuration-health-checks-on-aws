# pylint: disable = C0103, R0902, W1203, C0301
"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""
#This file comprises building meta-data and preparing health checks functions for the project
from validations import *
from awschecksexecutor import *
from comexecutor import *

###### Start Processing Checks  ######
# Create a dictionary mapping resource categories to processing functions
ascs_processing_functions = {

    "AWS Data Provider": process_aws_data_provider,
    "Volumes Check": process_abap_volumes_checks,
    "Detailed Monitoring": process_detailed_monitoring,
    "Instance Status" : process_aws_instance_status,

}

# function to process hana checks 
def process_ascs_checks(instance_id,checks, meta_data) :
    
    ec2_meta_data = ec2_instance_meta_data(instance_id)
    # Merge SAP and EC2 instance metadata
    full_meta_data =  process_meta_data(checks, instance_id, meta_data, ec2_meta_data)
    
    for  check in checks:
        sap_component = full_meta_data['sap_component']['S'].lower()
        
        if  "ascs" in sap_component or sap_component == "general" or sap_component == "Meta_Data":
            
            resource_category = check.get('resource_category', {}).get('S', '')
            type_of_check = check.get('type_of_check', {}).get('S', '')
            
            print (f"\n====Info : ascs checks category {resource_category} ====")
        
            # Call the appropriate processing function based on resource category
            if resource_category in ascs_processing_functions:
                ascs_processing_function = ascs_processing_functions[resource_category]
                ascs_processing_function(check, instance_id)
            elif type_of_check in 'command':
                process_cmd_based_cheks(check, instance_id)
                
            else:
                print(f"No processing function found for resource category: {resource_category}")
###### End Processing Checks  ######


  
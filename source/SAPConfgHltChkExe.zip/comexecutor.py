# pylint: disable = C0103, R0902, W1203, C0301
"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""
#This file comprises building common executing  functions for the project
from utilities import *
from awschecksexecutor import *

##### Start AWS_Data_Provider   #####
# executes and verifies AWS Data provider checks in the EC2.
def process_aws_data_provider(check, instance_id):
    
    compliance_id = check.get('compliance_id', {}).get('S', '')
    command = check.get('command', {}).get('S', '')
    check_description = check.get('check_description', {}).get('S', '')
    expected_string = check.get('expected_string', {}).get('S', '')
    resource_name = check.get('resource_name', {}).get('S', '')

    print ("\nInfo : processing the  check " + compliance_id +" ===> " + check_description)
    command_to_run = command
    value_in_ins = execute_runcommand(command_to_run, instance_id)
    
    if not value_in_ins:
        value_in_ins = "Not Available in Instance"
        compliance_status = "No"
    elif resource_name in  'Data_Provider_Version':
        compliance_status = compare_versions(expected_string, value_in_ins.strip())
        print("Info :  the version of Data Provider is --> " + compliance_status)
    elif expected_string in value_in_ins :
        compliance_status = "Yes"
    else :
        compliance_status = "No"
        
    print_compliance_status(compliance_status, expected_string, value_in_ins)
    #save
    set_saplense_status(instance_id, compliance_id, compliance_status, value_in_ins)
    pass
##### End AWS_Data_Provider   #####

###### Start All Other Command Based Checks  ######
def process_cmd_based_cheks(check, instance_id):
    print ("\nInfo : processing the  cmd based check " + check['compliance_id']['S']  +" ===> " + check['check_description']['S'])
    
    compliance_status = "Yes"
    value_in_ins = execute_runcommand(check['command']['S'], instance_id)
    expected_string = check["expected_string"]['S']

    if not value_in_ins :
        compliance_status = "No"
        value_in_ins = "Not Available in Instance"
        
    else :
        if value_in_ins.lower() in expected_string.lower():
            compliance_status = "Yes"
        else :
            compliance_status = "No"
    print_compliance_status(compliance_status, expected_string, value_in_ins)            
    set_saplense_status(instance_id, check['compliance_id']['S'], compliance_status, value_in_ins)

###### End All Other Command Based Checks  ######

###### Start SAP  volume checks ######
#Describe volumes are stored into this global dic to avoid API call for every check.
volume_info_dic = {}
def process_abap_volumes_checks(check, instance_id):
    global volume_info_dic
    volume_id = execute_runcommand( check['command']['S'], instance_id)
    value_in_ins = None
    compliance_status = "No"
    if not volume_id :
        print ("Error: cound not fetch the volume id")
        print ("Error: check ID #" + check['compliance_id']['S']+" -- " +check['check_description']['S']+ " could not execute ")
        value_in_ins = "Not Available in Instance"
        set_saplense_status(instance_id, check['compliance_id']['S'], compliance_status,value_in_ins)
        return
    print("Info :  the volume ID --> " + volume_id)
    #get the volume info if is already not fetched 
    if volume_id not in volume_info_dic:
        # save it in global volume_info_dic to avoid API call for every check.
        volume_info_dic = describe_volume(volume_id)
        print("Info :  Successfully describe volume " + volume_id)
        
    value_in_ins = volume_info_dic[volume_id][check["pattern_string"]['S'].lower()]
    expected_string =check["expected_string"]['S']
    if 'iops' in check["pattern_string"]['S'].lower() :
        if volume_info_dic[volume_id]['iops'] >= int(check["expected_string"]['S']):       
            print ("Gree ---> Baseline : " + expected_string  +",  Current Status : " + str(value_in_ins))
            compliance_status = "Yes" 
    elif 'size' in check["pattern_string"]['S'].lower() :
        if volume_info_dic[volume_id]['size'] >= int(check["expected_string"]['S']):
            print ("Gree ---> Baseline : " + expected_string  +",  Current Status : " + str(value_in_ins))
            compliance_status = "Yes"
    elif 'throughput' in check["pattern_string"]['S'].lower() :
        if volume_info_dic[volume_id]['throughput'] >= int(check["expected_string"]['S']):
            print ("Gree ---> Baseline : " + expected_string  +",  Current Status : " + str(value_in_ins))
            compliance_status = "Yes"
    else :
        if volume_info_dic[volume_id][check["pattern_string"]['S']].lower() in check["expected_string"]['S'].lower():
            print ("Gree ---> Baseline : " + expected_string  +",  Current Status : " + str(value_in_ins))
            compliance_status = "Yes"
    
    if compliance_status == 'No':
        print ("Red ---> Baseline : " + expected_string  +",  Current Status : " + str(value_in_ins))
        
    set_saplense_status(instance_id, check['compliance_id']['S'], compliance_status,str(value_in_ins))
  
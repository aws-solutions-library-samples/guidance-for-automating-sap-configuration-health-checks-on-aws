# pylint: disable = C0103, R0902, W1203, C0301
"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""
#This file comprises building common executing  functions for the project
from utilities import *
from awschecksexecutor import *

##### Start AWS_Data_Provider   #####
# executes and verifies AWS Data provider checks in the EC2.
def process_aws_data_provider(check, instance_id):
    
    compliance_id = check.get('compliance_id', {}).get('S', '')
    command = check.get('command', {}).get('S', '')
    check_description = check.get('check_description', {}).get('S', '')
    expected_string = check.get('expected_string', {}).get('S', '')
    resource_name = check.get('resource_name', {}).get('S', '')

    print ("\nInfo : processing the  check " + compliance_id +" ===> " + check_description)
    command_to_run = command
    value_in_ins = execute_runcommand(command_to_run, instance_id)
    
    if not value_in_ins:
        value_in_ins = "Not Available in Instance"
        compliance_status = "No"
    elif resource_name in  'Data_Provider_Version':
        compliance_status = compare_versions(expected_string, value_in_ins.strip())
        print("Info :  the version of Data Provider is --> " + value_in_ins.strip())
    elif expected_string in value_in_ins :
        compliance_status = "Yes"
    else :
        compliance_status = "No"
        
    print_compliance_status(compliance_status, expected_string, value_in_ins)
    #save
    set_saplense_status(instance_id, compliance_id, compliance_status, value_in_ins)
    pass
##### End AWS_Data_Provider   #####

###### Start All Other Command Based Checks  ######
def process_cmd_based_cheks(check, instance_id):

    print ("\nInfo : processing the  cmd based check " + check['compliance_id']['S']  +" ===> " + check['check_description']['S'])
    
    compliance_status = "Yes"
    value_in_ins = execute_runcommand(check['command']['S'], instance_id)
    expected_string = check["expected_string"]['S']

    if not value_in_ins :
        compliance_status = "No"
        value_in_ins = "Not Available in Instance"
        
    else :
        if value_in_ins.lower() in expected_string.lower():
            compliance_status = "Yes"
        else :
            compliance_status = "No"
    print_compliance_status(compliance_status, expected_string, value_in_ins)            
    set_saplense_status(instance_id, check['compliance_id']['S'], compliance_status, value_in_ins)

###### End All Other Command Based Checks  ######

###### Start SAP  volume checks ######
#Describe volumes are stored into this global dic to avoid API call for every check.
volume_info_dic = {}
def process_abap_volumes_checks(check, instance_id):
    global volume_info_dic
    print ("\nInfo : processing the  cmd based check " + check['compliance_id']['S']  +" ===> " + check['check_description']['S'])
    volume_id = execute_runcommand( check['command']['S'], instance_id)
    value_in_ins = None
    compliance_status = "No"
    if not volume_id :
        print ("Error: cound not fetch the volume id")
        print ("Error: check ID #" + check['compliance_id']['S']+" -- " +check['check_description']['S']+ " could not execute ")
        value_in_ins = "Not Available in Instance"
        set_saplense_status(instance_id, check['compliance_id']['S'], compliance_status,value_in_ins)
        return
    print("Info :  the volume ID --> " + volume_id)
    #get the volume info if is already not fetched 
    if volume_id not in volume_info_dic:
        # save it in global volume_info_dic to avoid API call for every check.
        volume_info_dic = describe_volume(volume_id)
        print("Info :  Successfully describe volume " + volume_id)
        
    value_in_ins = volume_info_dic[volume_id][check["pattern_string"]['S'].lower()]
    expected_string =check["expected_string"]['S']
    if 'iops' in check["pattern_string"]['S'].lower() :
        if volume_info_dic[volume_id]['iops'] >= int(check["expected_string"]['S']):       
            print ("Gree ---> Baseline : " + expected_string  +",  Current Status : " + str(value_in_ins))
            compliance_status = "Yes" 
    elif 'size' in check["pattern_string"]['S'].lower() :
        if volume_info_dic[volume_id]['size'] >= int(check["expected_string"]['S']):
            print ("Gree ---> Baseline : " + expected_string  +",  Current Status : " + str(value_in_ins))
            compliance_status = "Yes"
    elif 'throughput' in check["pattern_string"]['S'].lower() :
        if volume_info_dic[volume_id]['throughput'] >= int(check["expected_string"]['S']):
            print ("Gree ---> Baseline : " + expected_string  +",  Current Status : " + str(value_in_ins))
            compliance_status = "Yes"
    else :
        if volume_info_dic[volume_id][check["pattern_string"]['S']].lower() in check["expected_string"]['S'].lower():
            print ("Gree ---> Baseline : " + expected_string  +",  Current Status : " + str(value_in_ins))
            compliance_status = "Yes"
    
    if compliance_status == 'No':
        print ("Red ---> Baseline : " + expected_string  +",  Current Status : " + str(value_in_ins))
        
    set_saplense_status(instance_id, check['compliance_id']['S'], compliance_status,str(value_in_ins))

###### Start other volume checks in SAP instances ######

#check if mount point usage percentage is less than threshold.
def compare_disk_usage(check, instance_id,expected_string, value_in_ins):
    
    compliance_status = "Yes"
    
    if int(expected_string) > int(value_in_ins):
        print(f"Green ---> Baseline disk usege : {expected_string}%, Total current usage: {value_in_ins}%")
    else:
        compliance_status = "No"
        print(f"Red ---> Baseline disk usege : {expected_string}%, Total current usage: {value_in_ins}%")
    
    set_saplense_status(instance_id, check['compliance_id']['S'], compliance_status, value_in_ins)

# all volumes into stays here 
volumes = {}    
volume_info = {}
#Reformat the volume serial number from volxxxxxxxxxx to vol-xxxxxxxxxx.
def volumes_format_serial(serial):
    
    if serial:
        return serial.replace('vol', 'vol-')
    return serial

#Extract and format serial numbers from a block device, considering children if present.
def volumes_extract_serials(device):
    
    serials = []
    if "children" in device:
        for child in device["children"]:
            if child.get("serial"):
                serials.append(volumes_format_serial(child["serial"]))
    else:
        if device.get("serial"):
            serials.append(volumes_format_serial(device["serial"]))
    return serials

#Process a single block device and update the corresponding dictionary.
def volumes_process_block_device(device,find_mount_point):
    global volumes
    mountpoint = device.get("mountpoint")
    serials = volumes_extract_serials(device)
    
    if mountpoint and find_mount_point in mountpoint:
        volumes[find_mount_point] = serials
    
        
def get_volume_info(instance_id, mount_point):
    
    blockdevices = execute_runcommand( "lsblk -sJ -o NAME,MOUNTPOINT,SERIAL,SIZE", instance_id)
    blockdevices = json.loads(blockdevices)
    for device in blockdevices.get("blockdevices", []):
        volumes_process_block_device(device, mount_point)

def volume_check(check, instance_id, volumes_list,metrics):
    global volume_info

    compliance_status = "Yes"
    expected_string = check["expected_string"]['S'].lower()
    pattern = metrics
    check_to_report = ''
    # Initialize totals for IOPS, size, and throughput
    total_iops = 0
    total_size = 0
    total_throughput = 0
    try:
        # Iterate over all volumes in the list
        for volume_id in volumes_list:
            if volume_id not in volume_info_dic:
                volume_info_dic[volume_id] = describe_volume(volume_id)
                print("Info: Successfully described volume " + volume_id)
            volume_info = volume_info_dic[volume_id]
            #{'vol-0ef0ebe95573982be': {'deleteontermination': 'True', 'state': 'in-use', 'availabilityzone': 'us-east-1a', 'encrypted': 'False', 'iops': 16000, 'multiattachenabled': False, 'size': 1200, 'snapshotid': '', 'throughput': 1000, 'volumetype': 'gp3'}}

            # Accumulate IOPS, size, and throughput
            if 'iops' in pattern:
                total_iops += volume_info[volume_id]['iops']
            elif 'size' in pattern:
                total_size += volume_info[volume_id]['size']
            elif 'throughput' in pattern:
                total_throughput += volume_info[volume_id]['throughput']
            else: 
                if volume_info[volume_id][pattern].lower() not in expected_string:
                    compliance_status = "No"
                    check_to_report += f"Volume {volume_id} is {pattern} {volume_info[volume_id][pattern]}."
                    print(f"Red ---> Volume {volume_id}  {pattern} Baseline: {expected_string}, Actual: {volume_info[volume_id][pattern].lower()}.")
                else:
                    print(f"Green ---> Volume {volume_id}  {pattern} Baseline: {expected_string}, Actual: {volume_info[volume_id][pattern].lower()}.")
                    
         # Evaluate totals for IOPS, size, and throughput
        if 'iops' in pattern:
            value_to_report = total_iops
            if total_iops < int(expected_string):
                compliance_status = "No"
                print(f"Red ---> Baseline IOPS: {expected_string}, Total IOPS: {total_iops}")
            else:
                print(f"Green ---> Baseline IOPS: {expected_string}, Total IOPS: {total_iops}")
    
        elif 'size' in pattern:
            value_to_report = total_size
            if total_size < int(expected_string.rstrip('g')):
                compliance_status = "No"
                print(f"Red ---> Baseline Size: {expected_string}, Total Size: {total_size}G")
            else:
                print(f"Green ---> Baseline Size: {expected_string}, Total Size: {total_size}G")
    
        elif 'throughput' in pattern:
            value_to_report = total_throughput
            if total_throughput < int(expected_string):
                compliance_status = "No"
                print(f"Red ---> Baseline Throughput: {expected_string}, Total Throughput: {total_throughput}")
            else:
                print(f"Green ---> Baseline Throughput: {expected_string}, Total Throughput: {total_throughput}")
                    # Check for encryption
        else:
            if compliance_status == "No":
                value_to_report = check_to_report
            else:
                value_to_report = expected_string
            
        
        # Set the SAP Lens status
        set_saplense_status(instance_id, check['compliance_id']['S'], compliance_status, str(value_to_report))
    
    except Exception as e:
        print (f"Error : Failed  volume_check function with error ! {str(e)}  ")

def volumes_checks(check, instance_id):
    global volumes
    
    try:
        # Split the pattern_string into two parts  pattern_string = "/usr/sap;iops"
        pattern_string_parts=  check["pattern_string"]['S'].split(';') #"/usr/sap;iops".split(';')
        mount_point = pattern_string_parts[0] # /usr/sap
        metrics = pattern_string_parts[1] # iops

        if 'free_size' in  metrics:
            #df -h | grep '/usr/sap$' | awk '{print $5}' -> 2%
            value_in_ins = execute_runcommand(check['command']['S'], instance_id)
            value_in_ins = value_in_ins.strip().split('%')[0]
            expected_string = check["expected_string"]['S'].strip().split('%')[0]
            compare_disk_usage (check, instance_id, expected_string, value_in_ins)
        else:
            if not volumes:
                get_volume_info (instance_id, mount_point )
            if mount_point in volumes:
                volume_check (check, instance_id,volumes[mount_point],metrics)
            else : 
                print (f"Error : in function volumes_checks -  {mount_point} mount is not avilable in the system ")
    except Exception as e:
        print (f"Error : Failed  volumes_checks function with error ! {str(e)}  ")
                
# pylint: disable = C0103, R0902, W1203, C0301
"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""
#This file comprises building meta-data and preparing health checks functions for the project
from validations import *
from awschecksexecutor import *
from comexecutor import *

full_meta_data = {}

###### Start SAP HANA volume checks ######
#Describe volumes are stored into this global dic to avoid API call for every check.
volume_info_dic = {}

def hana_volume_checks(check, instance_id):
    global volume_info_dic
    volume_id = execute_runcommand( check['command']['S'], instance_id)
    value_in_ins = None
    compliance_status = "No"
    if not volume_id :
        print ("Error: cound not fetch the volume id")
        print ("Error: check ID #" + check['compliance_id']['S']+" -- " +check['check_description']['S']+ " could not execute ")
        value_in_ins = "Not Avilable in Instannce"
        set_saplense_status(instance_id, check['compliance_id']['S'], compliance_status,value_in_ins)
        return
    print("Info :  the volume ID --> " + volume_id)
    #get the volume info if is already not fetched 
    if volume_id not in volume_info_dic:
        # save it in global volume_info_dic to avoid API call for every check.
        volume_info_dic = describe_volume(volume_id)
        print("Info :  Successfully describe volume " + volume_id)
    value_in_ins = volume_info_dic[volume_id][check["pattern_string"]['S'].lower()]
    expected_string =check["expected_string"]['S']
    if 'iops' in check["pattern_string"]['S'].lower() :
        if volume_info_dic[volume_id]['iops'] >= int(check["expected_string"]['S']):       
            print ("Gree ---> Baseline : " + expected_string  +",  Current Status : " + str(value_in_ins))
            compliance_status = "Yes" 
    elif 'size' in check["pattern_string"]['S'].lower() :
        if volume_info_dic[volume_id]['size'] >= int(check["expected_string"]['S']):
            print ("Gree ---> Baseline : " + expected_string  +",  Current Status : " + str(value_in_ins))
            compliance_status = "Yes"
    elif 'throughput' in check["pattern_string"]['S'].lower() :
        if volume_info_dic[volume_id]['throughput'] >= int(check["expected_string"]['S']):
            print ("Gree ---> Baseline : " + expected_string  +",  Current Status : " + str(value_in_ins))
            compliance_status = "Yes"
    else :
        if volume_info_dic[volume_id][check["pattern_string"]['S']].lower() in check["expected_string"]['S'].lower():
            print ("Gree ---> Baseline : " + expected_string  +",  Current Status : " + str(value_in_ins))
            compliance_status = "Yes"
    
    if compliance_status == 'No':
        print ("Red ---> Baseline : " + expected_string  +",  Current Status : " + str(value_in_ins))
        
    set_saplense_status(instance_id, check['compliance_id']['S'], compliance_status,str(value_in_ins))
    
# Function to check if all volumes are of type gp3 or gp2 or 
def aLL_volumes_type(check, instance_id):
    global volume_info_dic
    block_devices = block_device_mappings(instance_id)
    compliance_status = "Yes"
    value_in_ins = ''
    for block_device in block_devices:
        volume_id = block_device['Ebs'].get('VolumeId')
        
        if volume_id not in volume_info_dic:
            volume_info_dic = describe_volume(volume_id)
            print("Info :  Successfully describe volume " + volume_id)
        
        if volume_info_dic[volume_id]['volumetype'] not in check["expected_string"]['S']:
            compliance_status = "No"
            value_in_ins += f"Volume ID: {volume_id} is Volume type  : {volume_info_dic[volume_id]['volumetype']}"
            print( f"Red --> Volume ID: {volume_id} is Volume type : {volume_info_dic[volume_id]['volumetype']}")
    
    if compliance_status == 'Yes':
        print ("Green ---> All Volumes are " + check["expected_string"]['S'])
        value_in_ins = volume_info_dic[volume_id]['volumetype']
    #save the status to DYDB    
    set_saplense_status(instance_id, check['compliance_id']['S'], compliance_status, value_in_ins)

hana_volume_processing_functions = {
    "Volume_HANA_DATA": hana_volume_checks,
    "Volume_HANA_LOG": hana_volume_checks,
    "Volume_HANA_SHARED": hana_volume_checks,
    "ALL_Volumes_type": aLL_volumes_type
}

# This function is dedicated for volume related checks
#HANA Volume checks 
def process_hana_volumes_checks(check, instance_id):
    print ("\nInfo : processing the hana check ID " + check['compliance_id']['S']  +" ===> " + check['check_description']['S'])
    
    resource_name = check["resource_name"]['S']
    if  resource_name in hana_volume_processing_functions :
        hana_volume_processing_function = hana_volume_processing_functions[resource_name]
        hana_volume_processing_function(check, instance_id)

###### END SAP HANA DATA volume checks ######

###### Start  HANA Version ######
def process_hana_version(check, instance_id):
    print ("\nInfo : processing the hana check " + check['compliance_id']['S']  +" ===> " + check['check_description']['S'])
    compliance_status = "Yes"
    hava_version = execute_runcommand( check['command']['S'], instance_id)
    expected_string = check["expected_string"]['S']
    value_in_ins = hava_version
    
    if not hava_version :
        compliance_status = "No"
        value_in_ins = "Not Avilable in Instannce"
        print ("Error: cound not fetch the version")
        
    else :
        compliance_status = compare_versions(expected_string, value_in_ins)
    
    print_compliance_status(compliance_status, expected_string, value_in_ins)    
    set_saplense_status(instance_id, check['compliance_id']['S'], compliance_status, value_in_ins)
###### End HANA Version ######

###### Start Processing Checks  ######
# Create a dictionary mapping resource categories to processing functions
hana_processing_functions = {

    "AWS Data Provider": process_aws_data_provider,
    "HANA Volumes Check": process_hana_volumes_checks,
    "Detailed Monitoring": process_detailed_monitoring,
    "HDB Version" : process_hana_version,
    "Instance Status" : process_aws_instance_status,
}

# function to process hana checks 
def process_hana_checks(instance_id,checks, meta_data) :
    global full_meta_data
    ec2_meta_data = ec2_instance_meta_data(instance_id)
    # Merge SAP and EC2 instance metadata
    full_meta_data = process_meta_data(checks, instance_id, meta_data, ec2_meta_data)
    
    for  check in checks:
        resource_category = check.get('resource_category', {}).get('S', '')
        type_of_check = check.get('type_of_check', {}).get('S', '')
        print (f"\n====Info : Hana checks category {resource_category} ====")
        # Call the appropriate processing function based on resource category
        if resource_category in hana_processing_functions:
            hana_processing_function = hana_processing_functions[resource_category]
            hana_processing_function(check, instance_id)
        elif type_of_check in 'command':
            process_cmd_based_cheks(check, instance_id)
            
        else:
            print(f"No processing function found for resource category: {resource_category}")
###### End Processing Checks  ######


  
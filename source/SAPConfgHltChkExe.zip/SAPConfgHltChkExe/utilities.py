# pylint: disable = C0103, R0902, W1203, C0301
"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""
#This file contains configuration parameters and utility functions for the project

import boto3
import csv
import io
import os
import json
import pprint
import datetime
import time
from botocore.exceptions import ClientError
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
#configuration parameters
DYDB_TABLE = "sap_robo_lens_table" # os.environ.get('dydb_chk_tbl') 
DYDB_TABLE_META = "sap_robo_lens_meta_data" # os.environ.get('dydb_chk_tbl_mdata') 

# Commonly used objects
REGION = boto3.session.Session().region_name
S3Client = boto3.client("s3", region_name=REGION)
EC2Client = boto3.client('ec2')
DYDBClient = boto3.client("dynamodb", region_name=REGION)
S3_Bucket = os.environ.get('s3bucket') #"sap-robo-lense"#
SSM_Client = boto3.client('ssm')

# A function to get the ec2 client object    
def get_ec2_resource(instance_id):
    ec2_resource = boto3.resource('ec2')
    instance = ec2_resource.Instance(instance_id)
    return instance

# A function to get the dynamodb table object
def get_dynamodb_table_client(table_name):
    return DYDBClient.Table(table_name)

# Function to replace empty strings with None
def replace_empty_string_with_none(value):
    return None if value == '' else value
 
# Function to get iteam from dydb table with instance_id
def get_checks_from_dynamo(instance_id):
    response = DYDBClient.query(
        TableName=DYDB_TABLE,
        KeyConditionExpression='instance_id = :value',
        ExpressionAttributeValues={':value': {'S': instance_id}}
    )
    return response['Items']
    
# Function to get iteam from dydb table with instance_id
def get_meta_data_from_dynamo(instance_id):
    response = DYDBClient.query(
        TableName=DYDB_TABLE_META,
        KeyConditionExpression='instance_id = :value',
        ExpressionAttributeValues={':value': {'S': instance_id}}
    )
    return response['Items']

#Converts dictionary values to DynamoDB format.
def convert_to_dynamodb_format(data):
    dynamodb_data = {}
    for key, value in data.items():
        # Convert value to DynamoDB format
        dynamodb_data[key] = {'S': str(value)}  # Assuming all values are strings
    return dynamodb_data

# Function to save the meta_data or inventory in dynamodb table 
def save_dydb_meta_data(inventory_dict):
    try:
        DYDBClient.put_item(
            TableName=DYDB_TABLE_META,
            Item=inventory_dict
        )
        print(f'Successfully added the meta data to Dynamo DB')
    except Exception as e:
        print (f"Error : meta data save to dydb {str(e)}  ")
        raise e
        
    
#update the the current status in DYNAMODB and log activity in the S3 bucket            
def set_saplense_status(instance_id, compliance_id, compliance_status, value_of_ins):
    current_datetime = datetime.datetime.now()

    response = DYDBClient.update_item(                                       
        TableName=DYDB_TABLE,
        Key={
            'instance_id': {'S': instance_id},
            'compliance_id': {'S': compliance_id} 
        },
        UpdateExpression="set compliance_status = :cs, last_check_execution_time = :lct, value_of_ins= :vis ", 
        ExpressionAttributeValues={
          
          # decimal, Converts a finite Decimal instance to a rational number, exactly.
            ':cs': {'S': compliance_status},
            ':lct': {'S': str(current_datetime)},
            ':vis': {'S':  None if value_of_ins is None or len(value_of_ins) <= 0 else value_of_ins} 
        },
        ReturnValues="UPDATED_NEW"
    )
    return response

def process_meta_data(check, instance_id, meta_data, ec2_meta_data):
    full_meta_data= {}
    ec2_meta_data = convert_to_dynamodb_format(ec2_meta_data)
    # Iterate through each dictionary in instance_meta
    for instance_data in meta_data:
    # Merge ec2_meta_data with instance_data
        full_meta_data = {**instance_data, **ec2_meta_data}
    save_dydb_meta_data(full_meta_data)
    # Process Meta_Data items
    return full_meta_data


#execute the runncommands     
def execute_runcommand(run_command,instanceid):
    print("Command:  to be executed  ---> " + run_command  ) 
    client = SSM_Client
    response = client.send_command(
        InstanceIds=[instanceid],
        DocumentName='AWS-RunShellScript',
        Parameters={
            'commands': [
                # Simple test if a file exists
                run_command
            ]
        }
    )
    command_id = response['Command']['CommandId']
    tries = 0
    output = 'False'
    while tries < 1000:
        tries = tries + 1
        try:
            #time.sleep(0.1)  # some delay always required...
            result = client.get_command_invocation(
                CommandId=command_id,
                InstanceId=instanceid,
            )
            
            if result['Status'] == 'InProgress':
                continue
            output = result['StandardOutputContent']
            break
        except client.exceptions.InvocationDoesNotExist:
            continue
    return output.strip()

# Function to compare version numbers
def compare_versions(expected_version, actual_version):
    # Split the version strings into components
    expected_components = expected_version.split('.')
    actual_components = actual_version.split('.')
    # Convert components to integers for comparison
    expected_components = list(map(int, expected_components))
    actual_components = list(map(int, actual_components))
    
    # Compare each component of the version numbers
    for expected, actual in zip(expected_components, actual_components):
        if actual < expected:
            return 'No'
        elif actual > expected:
            return 'Yes'
    # If all components are equal or if actual version has more components, return 'Yes'
    return 'Yes' if len(actual_components) >= len(expected_components) else 'No'

# Print the Compliance Status to cloud watch logs
def print_compliance_status(compliance_status, expected_string, value_in_ins):
    if compliance_status == "Yes":
        print ("Green ---> Baseline : " + expected_string  +", Current Status : " + value_in_ins)
    else :
        print ("Red ---> Baseline : " + expected_string  +", Current Status : " + value_in_ins)

# Helper function to handle Unicode properly when writing to CSV
def utf_8_encoder(self, unicode_csv_data):
    for line in unicode_csv_data:
        yield [cell.decode('utf-8') if isinstance(cell, bytes) else '' if cell is None else cell for cell in line]

#save the data to s3 
def save_data_s3(instance_id):

    current_datetime = datetime.datetime.now()
    try:
        response  =  get_checks_from_dynamo(instance_id)
        # Check if there are any records matching the instance_id
        if len(response) <= 0 :
            print("Error : No records found for the given instance")
            return
        # Prepare data for CSV file
        checks = response
        headers =  list(checks[0].keys())
        # Exclude specified columns for CSV
        excluded_columns = ['command']
        headers = [header for header in headers if header not in excluded_columns]
        html_table = ""
        # Write records to CSV
        csv_data = [headers]
        for check in checks:
            row = [check.get(header, {}).get('S', '') for header in headers]
            csv_data.append(row)
            if check['compliance_status']['S'] == 'No' and check['complexity']['S'] == 'high':
                compliance_id = check['compliance_id']['S'] 
                check_description = check['check_description']['S'] 
                expected_string =  check['expected_string']['S'] 
                value_of_ins =  check['value_of_ins']['S'] 

                html_table += f"""
                    <tr style="border: 1px solid red;">
                       
                        <td style="border: 1px solid red; padding: 8px; text-align: left;">{check_description}</td>
                        <td style="border: 1px solid red; padding: 8px; text-align: center;">{value_of_ins}</td>
                        <td style="border: 1px solid red; padding: 8px; text-align: center;">{expected_string}</td>

                    </tr>
                """
        # Upload CSV file to S3
        time_fmatd_str = current_datetime.strftime("%Y-%m-%d_%H-%M-%S")
        s3_pfx_time_fmatd_str = current_datetime.strftime("%y/%m/%d/%H")
        csv_filename = f"{instance_id}_{time_fmatd_str}.csv"
        s3_key = f"all_results/{instance_id}/{s3_pfx_time_fmatd_str}/{csv_filename}"  # S3 key to store the file, using the section key as a folder name
        
        csv_content = '\n'.join([','.join(row) for row in csv_data])
        S3Client.put_object(Body=csv_content, Bucket=S3_Bucket, Key=s3_key)
        print(f"Info : {instance_id} CSV file uploaded to S3: s3://{S3_Bucket}/{s3_key}")
        S3Client.put_object(Body=csv_content, Bucket=S3_Bucket, Key="last-check-results/"+instance_id+".csv")
        
        print(f"Info : {instance_id} CSV file uploaded to S3: s3://{S3_Bucket}/'last-check-results/'+{instance_id}.csv")
        save_meta_data_s3(instance_id)
        send_email(instance_id, checks, html_table)
    except ClientError as e:
        print(f"Error: Failed to query DynamoDB or save records to S3! {str(e)}")
        return False
    except Exception as e:
        print (f"Error : Failed to query DynamoDB or save records to S3! {str(e)}  ")
        print ("Error : Results are not saved in  S3!")
        
# save the meta_data into s3 bucket
def save_meta_data_s3(instance_id):
    current_datetime = datetime.datetime.now()

    items  =  get_meta_data_from_dynamo(instance_id)
    # Check if any records are found
    
    print(f"Info : {instance_id} meta data saved to S3")
    if not items:
        return {
            'statusCode': 404,
            'body': 'No record found for the specified instance ID.'
        }
    
    # Extract keys and values from the DynamoDB item
    item = items[0]
    keys = list(item.keys())
    values = [item[key]['S'] for key in keys]
    
    # Convert keys and values to CSV format
    csv_content = ",".join(keys) + "\n" + ",".join(values)
    
    # Upload CSV data to S3
    current_datetime = datetime.datetime.now()
    time_fmatd_str = current_datetime.strftime("%Y-%m-%d_%H-%M-%S")
    s3_pfx_time_fmatd_str = current_datetime.strftime("%y/%m/%d/%H")
    csv_filename = f"{item['instance_id']['S']}_meta{time_fmatd_str}.csv"
    s3_key = f"all_results/meta/{item['instance_id']['S']}/{s3_pfx_time_fmatd_str}/{csv_filename}"  # S3 key to store the file
    
    S3Client.put_object(Body=csv_content.encode(), Bucket=S3_Bucket, Key=s3_key)
    S3Client.put_object(Body=csv_content.encode(), Bucket=S3_Bucket, Key="metadata/"+instance_id+".csv")
    
    return {
        'statusCode': 200,
        'body': f'Data for instance ID {item["instance_id"]["S"]} has been written to S3 in CSV format.'
    }

# sending email 
#https://docs.aws.amazon.com/ses/latest/dg/send-email-raw.html
def generate_email_header(meta_data):
    email_header = f"""
        <html>
        <head>
            <style>
                table {{
                    border-collapse: collapse;
                    width: 100%;
                }}
                th, td {{
                    border: 1px solid red;
                    padding: 8px;
                    text-align: left;
                }}
                th {{
                    background-color: #f2f2f2;
                    font-weight: bold;
                }}
            </style>
        </head>
        <body>
            Hello, Team!
            <p>Please review the high priority configuration drift resport.</p>
            AWS Account ID : <b> {meta_data[0]['ec2_account_id']['S']} </b><br/>
            System Type : <b> {meta_data[0]['type_of_system']['S']} </b><br/>
            SAP Application : <b> {meta_data[0]['sap_application']['S']} </b><br/>
            Sid : <b> {meta_data[0]['sid']['S']} </b><br/>
            SAP Component : <b> {meta_data[0]['sap_component']['S']} </b><br/>
            AWS instance Id : <b> {meta_data[0] ['instance_id']['S']} </b><br/>
        <br/>
        <br/>
            <table>
                <tr>
                    <th>Check Description</th>
                    <th>Actual Value in System </th>
                    <th>Expected Value in System </th>
                </tr>
                """
    return email_header

# Generate email botton 
def generate_email_bottom(instance_id):
    email_bottom = f"""
                
            </table>
             <footer>
                For more deatils please click -  
                <a href = 'https://us-east-1.quicksight.aws.amazon.com/sn/analyses/6e3a1304-bac7-4298-840d-2cc0278ab3e7/sheets/57e9b30a-37fe-4683-852a-e38c2503e07a#p.instanceid={instance_id}'>
                    {instance_id} 
                </a>
                <br/>  
            </footer>
        </body>
        </html>
    """
    return email_bottom

def generate_csv_email(checks):
    #Generate CSV content from checks data
    headers = list(checks[0].keys())
    # Exclude additional columns for email attachment
    excluded_columns_email = ['command','created_time', 'sap_application',
                            'type_of_check', 'sap_lens_topic', 'sap_lens_category', 'sap_lens_bp_suggestion']
    headers_email = [header for header in headers if header not in excluded_columns_email]
    # Write checks to CSV for email attachment
    csv_data_email = [headers_email]
    for record in checks:
        row = [record.get(header, {}).get('S', '') for header in headers_email]
        csv_data_email.append(row)
    # Convert CSV data to string
    csv_content_email = '\n'.join([','.join(row) for row in csv_data_email])
    return csv_content_email

def send_email(instance_id, checks, html_table):
    try:
        meta_data = get_meta_data_from_dynamo(instance_id)
        # for email
        html_head = generate_email_header(meta_data)
        html_bottom = generate_email_bottom(instance_id)
        csv_content_email = generate_csv_email(checks)
        html_content = html_head + html_table + html_bottom
        # Send email with CSV attachment using SES
        ses = boto3.client('ses')
        subject = f"""{meta_data[0]['type_of_system']['S']} - {meta_data[0]['sap_application']['S']} - {meta_data[0]['sap_component']['S']} Instance {instance_id} Config Drift Report """
        body = f'<html><body>{html_content}</body></html>'
        sender_email = meta_data[0]['responsible_team']['S']
        recipient_email = meta_data[0]['responsible_team']['S'] 
        # Create a multipart/mixed parent container.
        msg = MIMEMultipart('mixed')
        # Add subject, from and to lines.
        msg['Subject'] = subject 
        msg['From'] = sender_email 
        msg['To'] = recipient_email
        charset = "utf-8"
        # Create a multipart/alternative child container.
        msg_body = MIMEMultipart('alternative')
        htmlpart = MIMEText(body.encode(charset), 'html', charset)
        msg_body.attach(htmlpart)
        att = MIMEApplication(csv_content_email)
        att.add_header('Content-Disposition','attachment',filename=instance_id+".csv")
        msg.attach(msg_body)
        msg.attach(att)
        #Provide the contents of the email.
        response = ses.send_raw_email(
            Source=sender_email,
            Destinations=[
                recipient_email
            ],
            RawMessage={
                'Data':msg.as_string(),
            }
        )
        print(f"Email sent! {recipient_email} Message ID: {response['MessageId']}")
    except ClientError as e:
        print(f"Error: {e.response['Error']['Message']}")

"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""
# This file contains functions that evaluate the checks to be executed.

from hanachecksexecutor import *
from paschecksexecutor import *
from ascschecksexecutor import *
from erschecksexecutor import *
from appchecksexecutor import *

def get_sap_sys_meta_data(instance_id):
    # Determine system_type from Meta_Data
    meta_data = get_meta_data_from_dynamo(instance_id)
    for item in meta_data:
        print("Info : SAP Component Type is " + item['sap_component']['S'])
        sap_resource_type = item['sap_component']['S']

    return sap_resource_type, meta_data
    
def exec_checks(instance_id):
    # Determine the system type from Meta_Data
    sap_resource_type, meta_data = get_sap_sys_meta_data(instance_id)
    #Read Dynamo DB table where instance_id = input instance 
    checks = get_checks_from_dynamo(instance_id)
    print("Info : System Type is " + sap_resource_type)
    
    if sap_resource_type == 'HANA_DB_Primary':
        process_hana_checks(instance_id,checks,meta_data)
        
    elif sap_resource_type == 'HANA_DB_Standby':
        process_hana_checks(instance_id,checks,meta_data)
        
    elif sap_resource_type == 'HANA_DB':
        process_hana_checks(instance_id,checks,meta_data)
        
    elif sap_resource_type == 'PAS':
        process_pas_checks(instance_id,checks,meta_data)
        
    elif sap_resource_type == 'ASCS':
        process_ascs_checks(instance_id, checks, meta_data)
    
    elif sap_resource_type == 'ERS':
        process_ers_checks(instance_id,checks,meta_data)
    
    elif 'APP' in sap_resource_type:
        process_app_checks(instance_id, checks, meta_data)
    
    else:
        print(f"Unknown SAP Component Type: {sap_resource_type}")
    save_data_s3(instance_id)
    return

# invoke sap-lens-robo-checks lambda asynchronously for aws instance_id 
def invoke_lambda(instance_id):
      # invoke sap-robo-lens lambda asynchronously for the exisiting values 
    lambda_client = boto3.client('lambda')
    
    payload = {'sapinstanceID': instance_id}
    try:
        # Invoke the second Lambda function asynchronously without waiting for its response.
        lambda_client.invoke(
            FunctionName="SAPConfgHltChkExe",
            InvocationType='Event',
            Payload=json.dumps(payload)
        )
        print(f"Invoked second Lambda function for checks: {instance_id}")
    except Exception as e:
        print(f"Error invoking Lambda function: {e}")
      
    return
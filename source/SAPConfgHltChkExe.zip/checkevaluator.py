"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""
# This file contains functions that evaluate the checks to be executed.

from hanachecksexecutor import *
from paschecksexecutor import *
from ascschecksexecutor import *
from erschecksexecutor import *
from appchecksexecutor import *


def exec_checks(instance_id):
    
    # Determine the system type from Meta_Data
    # Get the Metra Data for the instance 
    print("SAP Component Finder ")
    meta_data = get_all_meta_data_from_dynamo(instance_id)
    
    for meta_data_item in meta_data:
        
        print("Info : SAP Component Type is " + meta_data_item['sap_component']['S'])
        
        sap_resource_type = meta_data_item['sap_component']['S']
        compliance_id_prefix = meta_data_item['instance_no']['S']
        pprint.pprint(compliance_id_prefix)
        if sap_resource_type == 'HANA_DB_Primary':
            print("Info : System Type is " + sap_resource_type)
            checks = get_checks_from_dynamo(instance_id, compliance_id_prefix)
            process_hana_checks(instance_id,checks,meta_data_item)
            
        elif sap_resource_type == 'HANA_DB_Standby':
            print("Info : System Type is " + sap_resource_type)
            checks = get_checks_from_dynamo(instance_id, compliance_id_prefix)
            process_hana_checks(instance_id,checks,meta_data_item)
            
        elif sap_resource_type == 'HANA_DB':
            print("Info : System Type is " + sap_resource_type)
            checks = get_checks_from_dynamo(instance_id, compliance_id_prefix)
            process_hana_checks(instance_id,checks,meta_data_item)
            
        elif sap_resource_type == 'PAS':
            print("Info : System Type is " + sap_resource_type)
            checks = get_checks_from_dynamo(instance_id, compliance_id_prefix)
            process_pas_checks(instance_id,checks,meta_data_item)
            
        elif sap_resource_type == 'ASCS':
            print("Info : System Type is " + sap_resource_type)
            checks = get_checks_from_dynamo(instance_id, compliance_id_prefix)
            process_ascs_checks(instance_id, checks, meta_data_item)
        
        elif sap_resource_type == 'ERS':
            print("Info : System Type is " + sap_resource_type)
            checks = get_checks_from_dynamo(instance_id, compliance_id_prefix)
            process_ers_checks(instance_id,checks,meta_data_item)
        
        elif 'APP' in sap_resource_type:
            print("Info : System Type is " + sap_resource_type)
            checks = get_checks_from_dynamo(instance_id, compliance_id_prefix)
            process_app_checks(instance_id, checks, meta_data_item)
        
        else:
            
            print(f"Unknown SAP Component Type: {sap_resource_type}")
            
        save_data_s3(instance_id,compliance_id_prefix)
        
    

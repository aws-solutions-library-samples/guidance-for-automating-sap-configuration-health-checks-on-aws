# pylint: disable = C0103, R0902, W1203, C0301
"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""
#This file contains validation for enduser input functions for the project
from awschecksexecutor import *

# check if the instance is avilable or not 
def check_instance_availability(instance_id):
    print("Info : Check the AWS Instance Availability ")
    try:
        instance = ec2_instance_meta_data(instance_id)
        state = instance['ec2_state']
        # Check if the instance is in 'running' state
        if state == 'running':
            print(f"Info : Instance {instance_id} is running.")
            return True
        else:
            print(f"Error  : Instance {instance_id} is not running. Current state: {state.get('Name')}")
            return False
    except Exception as e:
        # If an error occurs, return an error message
        print(f"Error : {str(e)}")
        print((f"Error : No checks are executed for instance : {instance_id} while instance is unavilable"))
        return False
    



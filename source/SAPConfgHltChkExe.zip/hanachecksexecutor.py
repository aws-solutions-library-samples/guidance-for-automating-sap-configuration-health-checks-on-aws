# pylint: disable = C0103, R0902, W1203, C0301
"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""
#This file comprises building meta-data and preparing health checks functions for the project
from validations import *
from awschecksexecutor import *
from comexecutor import *

full_meta_data = {}

###### Start SAP HANA volume checks ######
#Describe volumes are stored into this global dic to avoid API call for every check.
volume_info_dic = {}
hana_volumes =  {}

def format_serial(serial):
    """Reformat the volume serial number from volxxxxxxxxxx to vol-xxxxxxxxxx."""
    if serial:
        return serial.replace('vol', 'vol-')
    return serial


def extract_serials(device):
    """Extract and format serial numbers from a block device, considering children if present."""
    serials = []
    if "children" in device:
        for child in device["children"]:
            if child.get("serial"):
                serials.append(format_serial(child["serial"]))
    else:
        if device.get("serial"):
            serials.append(format_serial(device["serial"]))
    return serials

def process_block_device(device):
    global hana_volumes
    
    """Process a single block device and update the corresponding dictionary."""
    mountpoint = device.get("mountpoint")
    serials = extract_serials(device)
    
    if mountpoint and "/hana/data" in mountpoint:
        hana_volumes["/hana/data"] = serials
    elif mountpoint and "/hana/log" in mountpoint:
        hana_volumes["/hana/log"] = serials
    elif mountpoint and "/usr/sap" in mountpoint:
        hana_volumes["/usr/sap"] = serials
    elif mountpoint and "/hana/shared" in mountpoint:
        hana_volumes["/hana/shared"] = serials

        
def hana_volume_info(instance_id):
    
    blockdevices = execute_runcommand( "lsblk -sJ -o NAME,MOUNTPOINT,SERIAL,SIZE", instance_id)
    blockdevices = json.loads(blockdevices)
    for device in blockdevices.get("blockdevices", []):
        process_block_device(device)
    

def hana_volume_check(check, instance_id, hana_volumes_list):
    global volume_info_dic

    compliance_status = "Yes"
    expected_string = check["expected_string"]['S'].lower()
    pattern = check["pattern_string"]['S'].lower()
    check_to_report = ''
    # Initialize totals for IOPS, size, and throughput
    total_iops = 0
    total_size = 0
    total_throughput = 0
    try:
        # Iterate over all volumes in the list
        for volume_id in hana_volumes_list:
            if volume_id not in volume_info_dic:
                volume_info_dic[volume_id] = describe_volume(volume_id)
                print("Info: Successfully described volume " + volume_id)
            volume_info = volume_info_dic[volume_id]
            #{'vol-0ef0ebe95573982be': {'deleteontermination': 'True', 'state': 'in-use', 'availabilityzone': 'us-east-1a', 'encrypted': 'False', 'iops': 16000, 'multiattachenabled': False, 'size': 1200, 'snapshotid': '', 'throughput': 1000, 'volumetype': 'gp3'}}

            # Accumulate IOPS, size, and throughput
            if 'iops' in pattern:
                total_iops += volume_info[volume_id]['iops']
            elif 'size' in pattern:
                total_size += volume_info[volume_id]['size']
            elif 'throughput' in pattern:
                total_throughput += volume_info[volume_id]['throughput']
            else: 
                if volume_info[volume_id][pattern].lower() not in expected_string:
                    compliance_status = "No"
                    check_to_report += f"Volume {volume_id} is {pattern} {volume_info[volume_id][pattern]}."
                    print(f"Red ---> Volume {volume_id}  {pattern} Baseline: {expected_string}, Actual: {volume_info[volume_id][pattern].lower()}.")
                else:
                    print(f"Green ---> Volume {volume_id}  {pattern} Baseline: {expected_string}, Actual: {volume_info[volume_id][pattern].lower()}.")
                    
         # Evaluate totals for IOPS, size, and throughput
        if 'iops' in pattern:
            value_to_report = total_iops
            if total_iops < int(expected_string):
                compliance_status = "No"
                print(f"Red ---> Baseline IOPS: {expected_string}, Total IOPS: {total_iops}")
            else:
                print(f"Green ---> Baseline IOPS: {expected_string}, Total IOPS: {total_iops}")
    
        elif 'size' in pattern:
            value_to_report = total_size
            if total_size < int(expected_string.rstrip('g')):
                compliance_status = "No"
                print(f"Red ---> Baseline Size: {expected_string}, Total Size: {total_size}G")
            else:
                print(f"Green ---> Baseline Size: {expected_string}, Total Size: {total_size}G")
    
        elif 'throughput' in pattern:
            value_to_report = total_throughput
            if total_throughput < int(expected_string):
                compliance_status = "No"
                print(f"Red ---> Baseline Throughput: {expected_string}, Total Throughput: {total_throughput}")
            else:
                print(f"Green ---> Baseline Throughput: {expected_string}, Total Throughput: {total_throughput}")
                    # Check for encryption
        else:
            if compliance_status == "No":
                value_to_report = check_to_report
            else:
                value_to_report = expected_string
            
        
        # Set the SAP Lens status
        set_saplense_status(instance_id, check['compliance_id']['S'], compliance_status, str(value_to_report))
    
    except Exception as e:
        print (f"Error : Failed hana_volume_check function with error ! {str(e)}  ")


def hana_data_volume_checks(check, instance_id):
    global hana_volumes
    
    if 'free_size' in   check["pattern_string"]['S'].lower():
        
        value_in_ins = execute_runcommand(check['command']['S'], instance_id)
        expected_string = check["expected_string"]['S'].strip().split('%')[0]
        compare_disk_usage (check, instance_id, expected_string, value_in_ins)
        
    else:
            
        if not hana_volumes:
            hana_volume_info (instance_id )
        if "/hana/data" in hana_volumes:
            hana_volume_check (check, instance_id,hana_volumes["/hana/data"] )
        else : 
            print (f"Error : in function hana_data_volume_checks -  /hana/data mount is not avilable in the system ")
            

def hana_log_volume_checks(check, instance_id):
    global hana_volumes
    if 'free_size' in   check["pattern_string"]['S'].lower():
        
        value_in_ins = execute_runcommand(check['command']['S'], instance_id)
        expected_string = check["expected_string"]['S'].strip().split('%')[0]
        compare_disk_usage (check, instance_id, expected_string, value_in_ins)
        
    else:
        if not hana_volumes:
            hana_volume_info (instance_id )
    
        if "/hana/log" in hana_volumes:
            hana_volume_check (check, instance_id,hana_volumes["/hana/log"] )
        else : 
            print (f"Error : in function hana_log_volume_checks -  /hana/log mount is not avilable in the system ")
        

def hana_shared_volume_checks(check, instance_id):
    global hana_volumes
    if 'free_size' in   check["pattern_string"]['S'].lower():
        
        value_in_ins = execute_runcommand(check['command']['S'], instance_id)
        expected_string = check["expected_string"]['S'].strip().split('%')[0]
        compare_disk_usage (check, instance_id, expected_string, value_in_ins)
        
    else:
        if not hana_volumes:
            hana_volume_info (instance_id )
        
        if "/hana/shared" in hana_volumes:
            hana_volume_check (check, instance_id,hana_volumes["/hana/shared"] )
        else : 
            print (f"Error : in function hana_shared_volume_checks -  /hana/shared mount is not avilable in the system ")

    
# Function to check if all volumes are of type gp3 or gp2 or 
def aLL_volumes_type(check, instance_id):
    global volume_info_dic
    block_devices = block_device_mappings(instance_id)
    compliance_status = "Yes"
    value_in_ins = ''
    for block_device in block_devices:
        volume_id = block_device['Ebs'].get('VolumeId')
        
        if volume_id not in volume_info_dic:
            volume_info_dic = describe_volume(volume_id)
            print("Info :  Successfully describe volume " + volume_id)
        
        if volume_info_dic[volume_id]['volumetype'] not in check["expected_string"]['S']:
            compliance_status = "No"
            value_in_ins += f"Volume ID: {volume_id} is Volume type  : {volume_info_dic[volume_id]['volumetype']}"
            print( f"Red --> Volume ID: {volume_id} is Volume type : {volume_info_dic[volume_id]['volumetype']}")
    
    if compliance_status == 'Yes':
        print ("Green ---> All Volumes are " + check["expected_string"]['S'])
        value_in_ins = volume_info_dic[volume_id]['volumetype']
    #save the status to DYDB    
    set_saplense_status(instance_id, check['compliance_id']['S'], compliance_status, value_in_ins)

hana_volume_processing_functions = {
    "Volume_HANA_DATA": hana_data_volume_checks,
    "Volume_HANA_LOG": hana_log_volume_checks,
    "Volume_HANA_SHARED": hana_shared_volume_checks,
    #"ALL_Volumes_type": aLL_volumes_type
}

# This function is dedicated for volume related checks
#HANA Volume checks 
def process_hana_volumes_checks(check, instance_id):
    print ("\nInfo : processing the hana check ID " + check['compliance_id']['S']  +" ===> " + check['check_description']['S'])
    
    resource_name = check["resource_name"]['S']
    if  resource_name in hana_volume_processing_functions :
        hana_volume_processing_function = hana_volume_processing_functions[resource_name]
        hana_volume_processing_function(check, instance_id)

###### END SAP HANA DATA volume checks ######

###### Start  HANA Version ######
def process_hana_version(check, instance_id):
    print ("\nInfo : processing the hana check " + check['compliance_id']['S']  +" ===> " + check['check_description']['S'])
    compliance_status = "Yes"
    hava_version = execute_runcommand( check['command']['S'], instance_id)
    expected_string = check["expected_string"]['S']
    value_in_ins = hava_version
    
    if not hava_version :
        compliance_status = "No"
        value_in_ins = "Not Available in Instance"
        print ("Error: cound not fetch the version")
        
    else :
        compliance_status = compare_versions(expected_string, value_in_ins)
    
    print_compliance_status(compliance_status, expected_string, value_in_ins)    
    set_saplense_status(instance_id, check['compliance_id']['S'], compliance_status, value_in_ins)
###### End HANA Version ######

###### SAP HANA Cluster  checks ######
SAPHana_cluster_rsc_output = ''
def check_key_in_line(line, key):
    # Split the key into two parts
    key_parts = key.split('=')

    # Check if the first part is present in the line
    if key_parts[0] in line:
        # Split the line into parts based on spaces
        line_parts = line.split()
        # Check if the key matches exactly with any part in the line
        for line_part in line_parts:
            if key_parts[0] in line_part and key == line_part:
                print("match found: " + line_part)
                return True
            elif key_parts[0] in line_part and key != line_part:
                print("No match : " + line_part)
                return False
        return True
    return False
    
def sap_hana_cluster_check_parameter(output, section, expected_value, *sub_keys):
    
    # Split the output into lines
    lines = output.splitlines()

    # Track if we are inside the relevant section
    inside_section = False

    for line in lines:
        # Check if the line starts a new section
        if line.strip().startswith(section):
            inside_section = True
        elif inside_section and line.strip() == "":
            # We have exited the relevant section
            inside_section = False

        if inside_section:
            # Check if all sub-keys are present in the line
            if all(sub_key.strip() in line for sub_key in sub_keys):
                print(f"Keys found in :  {line}")
                # Use check_key_in_line to find the exact match of the expected value
                if check_key_in_line(line, expected_value):
                    print(f"Green ---> Baseline : {expected_value}, value in instance : Found: {line.strip()}")
                    return 'Yes', f"Found: {line.strip()}"
            
    # If nothing was found, return the following message
    search_keys = f"{' '.join(sub_keys)} with expected value '{expected_value}'"
    print(f"Red ---> Baseline : {expected_value}, value in instance : {search_keys} not found in section '{section}'")
    
    return 'No', f"{search_keys} not found in section '{section}'."

def call_sap_hana_cluster_check_parameter(cmd_out, check, instance_id ):
    pattern = check['pattern_string']['S']
    expected_value = check['expected_string']['S']
    parts = pattern.split(";")
    section = parts[0]  # First part is the section
    sub_keys = parts[1:]  # Remaining parts are the sub_keys
    compliance_status, value_in_ins =  sap_hana_cluster_check_parameter(cmd_out, section, expected_value, *sub_keys)
    set_saplense_status(instance_id, check['compliance_id']['S'], compliance_status, value_in_ins)

def rsc_SAPHana_cluster_checks(check, instance_id):
    print (f"\n====Info : Hana checks category { (check['resource_name']['S']) } ====")
    global SAPHana_cluster_rsc_output
    if not SAPHana_cluster_rsc_output:
        # execute pcs resource config SAPHana_HDB_10-clone
        SAPHana_cluster_rsc_output = execute_runcommand(check['command']['S'], instance_id)
    
    call_sap_hana_cluster_check_parameter(SAPHana_cluster_rsc_output, check, instance_id)    

SAPHanaTopology_cluster_rsc_output = ''
def rsc_SAPHanaTopology_cluster_checks(check, instance_id):
    
    global SAPHanaTopology_cluster_rsc_output
    if not SAPHanaTopology_cluster_rsc_output:
        # execute pcs resource config SAPHana_HDB_10-clone
        SAPHanaTopology_cluster_rsc_output = execute_runcommand(check['command']['S'], instance_id)
        
    call_sap_hana_cluster_check_parameter(SAPHanaTopology_cluster_rsc_output, check, instance_id)  

SAPHana_VIP_cluster_rsc_output = ''
def rsc_SAPHana_VIP_cluster_checks(check, instance_id):
    
    global SAPHana_VIP_cluster_rsc_output
    if not SAPHana_VIP_cluster_rsc_output:
        # execute pcs resource config SAPHana_HDB_10-clone
        SAPHana_VIP_cluster_rsc_output = execute_runcommand(check['command']['S'], instance_id)
        
    call_sap_hana_cluster_check_parameter(SAPHana_VIP_cluster_rsc_output, check, instance_id)

cluster_properties_output = ''
def cluster_properties(check, instance_id):
    
    global cluster_properties_output
    if not cluster_properties_output:
        # execute pcs resource config SAPHana_HDB_10-clone
        cluster_properties_output = execute_runcommand(check['command']['S'], instance_id)
        
    call_sap_hana_cluster_check_parameter(cluster_properties_output, check, instance_id) 

cluster_config_stonith_output = ''
def cluster_config_stonith_checks(check, instance_id):
    
    global cluster_config_stonith_output
    if not cluster_config_stonith_output:
        # execute pcs resource config SAPHana_HDB_10-clone
        cluster_config_stonith_output = execute_runcommand(check['command']['S'], instance_id)
        
    call_sap_hana_cluster_check_parameter(cluster_config_stonith_output, check, instance_id) 

cluster_config_constraint_output = ''
def cluster_config_constraint_checks(check, instance_id):
    
    global cluster_config_constraint_output
    if not cluster_config_constraint_output:
        # execute pcs resource config SAPHana_HDB_10-clone
        cluster_config_constraint_output = execute_runcommand(check['command']['S'], instance_id)
        
    call_sap_hana_cluster_check_parameter(cluster_config_constraint_output, check, instance_id)

cluster_config_defaults_output = ''
def cluster_config_defaults_checks(check, instance_id):
    
    global cluster_config_defaults_output
    if not cluster_config_defaults_output:
        # execute pcs resource config SAPHana_HDB_10-clone
        cluster_config_defaults_output = execute_runcommand(check['command']['S'], instance_id)
        
    call_sap_hana_cluster_check_parameter(cluster_config_defaults_output, check, instance_id)    
    
hana_cluster_processing_functions = {
    "Cluster_Configuration_SAPHana": rsc_SAPHana_cluster_checks,
    "Cluster_Configuration_SAPHanaTopology": rsc_SAPHanaTopology_cluster_checks,
    "Cluster_Config_AWS_OIP": rsc_SAPHana_VIP_cluster_checks,
    "Cluster_Config_Properties": cluster_properties,
    "Cluster_Config_Stonith": cluster_config_stonith_checks,
    "Cluster_Config_Constraints": cluster_config_constraint_checks,
    "Cluster_Configuration_defaults": cluster_config_defaults_checks,
    "Cluster_Configuration_SAPHanaTopology_cmd": process_cmd_based_cheks
   
}

def process_hana_cluster_checks(check, instance_id):
    
    type_of_check = check.get('type_of_check', {}).get('S', '')
    resource_name = check["resource_name"]['S']
    print ("\nInfo : processing the hana check ID " + check['compliance_id']['S']  +" ===> " + check['check_description']['S'])
    if  resource_name in hana_cluster_processing_functions :
        
        hana_cluster_processing_function = hana_cluster_processing_functions[resource_name]
        hana_cluster_processing_function(check, instance_id)
    elif type_of_check in 'command':
        process_cmd_based_cheks(check, instance_id)
        
###### END SAP HANA Cluster  checks ######

###### Start Processing Checks  ######
# Create a dictionary mapping resource categories to processing functions
hana_processing_functions = {

    "AWS Data Provider": process_aws_data_provider,
    "HANA Volumes Check": process_hana_volumes_checks,
    "Volumes Check": volumes_checks,
    "Detailed Monitoring": process_detailed_monitoring,
    "HDB Version" : process_hana_version,
    "Instance Status" : process_aws_instance_status,
    "SAP HANA Cluster" : process_hana_cluster_checks
}

# function to process hana checks 
def process_hana_checks(instance_id, checks, meta_data) :
    global full_meta_data
    ec2_meta_data = ec2_instance_meta_data(instance_id)
    # Merge SAP and EC2 instance metadata
    full_meta_data = process_meta_data(checks, instance_id, meta_data, ec2_meta_data)
    
    for  check in checks:
        resource_category = check.get('resource_category', {}).get('S', '')
        type_of_check = check.get('type_of_check', {}).get('S', '')
        set_by = check.get('set_by', {}).get('S', '').strip()
        #print (f"\n====Info : Hana checks category {resource_category} ====")
        # Call the appropriate processing function based on resource category
        if set_by != 'AWS' : # all checks that are created by customres 
            process_cmd_based_cheks(check, instance_id)
        elif resource_category in hana_processing_functions:
            hana_processing_function = hana_processing_functions[resource_category]
            hana_processing_function(check, instance_id)
        elif type_of_check in 'command':
            process_cmd_based_cheks(check, instance_id)
        else:
            print(f"No processing function found for resource category: {resource_category}")
###### End Processing Checks  ######


  
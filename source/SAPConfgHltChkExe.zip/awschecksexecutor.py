# pylint: disable = C0103, R0902, W1203, C0301
"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""
#This file comprises building meta-data and preparing health checks functions for the project
from utilities import *

instance_metadata = {}

def meta_data_response(instance_id):
    try:
        # Get the information about the instance using describe_instances
        response = EC2Client.describe_instances(Filters=[{'Name': 'instance-id', 'Values': [instance_id]}])
        # If the instance is found
        if 'Reservations' in response and len(response['Reservations']) > 0:
            instance = response['Reservations'][0]['Instances'][0]    
            return instance
        else :
            print(f"Error : Instance {instance_id} not found.")
            return False
            
    except Exception as e:
        # If an error occurs, return an error message
        print(f"Error : {str(e)}")
        print((f"Error : No checks are executed for instance : {instance_id} while instance is unavilable"))
        return False
    

def ec2_instance_meta_data(instance_id):
    global instance_metadata
    if 'BlockDeviceMappings' not in instance_metadata:
        instance_metadata = meta_data_response(instance_id)
    # You can access individual metadata fields like this:
    ec2_metadata = {}
    cpu_options = instance_metadata.get('CpuOptions', {})
    ec2_metadata ['ec2_cores'] = cpu_options.get('CoreCount')
    ec2_metadata ['ec2_hypervisor'] = instance_metadata.get('Hypervisor')
    iam_instance_profile = instance_metadata.get('IamInstanceProfile', {})
    ec2_metadata ['ec2_iam'] = iam_instance_profile.get('Arn')
    ec2_metadata ['ec2_instance_type'] = instance_metadata.get('InstanceType')
    ec2_metadata ['ec2_key_name'] = instance_metadata.get('KeyName')
    maintenance_options = instance_metadata.get('MaintenanceOptions', {})
    ec2_metadata ['ec2_auto_recovery'] = maintenance_options.get('AutoRecovery')
    metadata_options = instance_metadata.get('MetadataOptions', {})
    ec2_metadata ['ec2_imdsv2'] = metadata_options.get('HttpTokens')
    monitoring = instance_metadata.get('Monitoring', {})
    ec2_metadata ['ec2_monitoring'] = monitoring.get('State')
    for network_interface in instance_metadata.get('NetworkInterfaces', []):
        ec2_metadata ['ec2_private_ip_address'] = network_interface.get('PrivateIpAddress')
        ec2_metadata ['ec2_subnet_id'] = network_interface.get('SubnetId')
        ec2_metadata ['ec2_vpc_id'] = network_interface.get('VpcId')
        ec2_metadata ['ec2_account_id'] = network_interface.get('OwnerId')
    placement = instance_metadata.get('Placement', {})
    ec2_metadata ['ec2_az'] = placement.get('AvailabilityZone')
    ec2_metadata ['ec2_os'] = instance_metadata.get('PlatformDetails')
    security_groups = instance_metadata.get('SecurityGroups', [])
    ec2_metadata ['ec2_security_groups'] = ""
    for security_group in security_groups:
        ec2_metadata ['ec2_security_groups'] += security_group.get('GroupId') + ";"
    state = instance_metadata.get('State', {})
    ec2_metadata ['ec2_state'] = state.get('Name')
    return ec2_metadata

# function to get block device mappings 
def block_device_mappings(instance_id):
    global instance_metadata
    if 'BlockDeviceMappings' not in instance_metadata:
        instance_metadata = meta_data_response(instance_id)
    response = instance_metadata.get('BlockDeviceMappings', [])
    return response

#Helper function to describe volume
def describe_volume(volume_id):
    volume_info1 ={}
    response = EC2Client.describe_volumes(VolumeIds=[volume_id])
    volume = response['Volumes'][0]
    volume_info1[volume_id] = {
        'deleteontermination': str(volume.get('Attachments', [{}])[0].get('DeleteOnTermination')),
        'state': volume.get('State'),
        'availabilityzone': volume.get('AvailabilityZone'),
        'encrypted': str(volume.get('Encrypted')),
        'iops': int(volume.get('Iops')),
        'multiattachenabled': volume.get('MultiAttachEnabled'),
        'size': int(volume.get('Size')),
        'snapshotid': volume.get('SnapshotId'),
        'throughput': int(volume.get('Throughput')),
        'volumetype': volume.get('VolumeType'),
        'multiattachenabled': volume.get('MultiAttachEnabled')
        
    }
    return volume_info1
    
###### Start Detailed Monitoring ######
#Instance Detailed Monitorings - Indicates whether detailed monitoring is enabled. Otherwise, basic monitoring is enabled.
#print (monitoring) # output 'disabled'|'disabling'|'enabled'|'pending'- enabled good status
def process_detailed_monitoring(check, instance_id):
    global instance_metadata
    
    monitoring = instance_metadata.get('Monitoring', {})
    compliance_status = "Yes"
    value_in_ins = monitoring.get('State')
    expected_string = check["expected_string"]['S']
    
    print ("Info : Detailed Monitoring is " + value_in_ins)

    if value_in_ins not in check["expected_string"]['S']:
        compliance_status = "No"
    elif value_in_ins in check["expected_string"]['S']:
        compliance_status = "Yes"    
    else :
        compliance_status = "No"

    print_compliance_status(compliance_status, expected_string, value_in_ins)
    #save the status to DYDB    
    set_saplense_status(instance_id, check['compliance_id']['S'], compliance_status, value_in_ins)
###### End  Detailed Monitoring ######

   
###### Start AWS Instance Running Status ######
#AWS Instance running status
#https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/ec2.html#EC2.Instance.state
#output : {'Code': 16, 'Name': 'running'}
def check_aws_instance_running_status(check, instance_id):
    global instance_metadata
    compliance_status = "Yes"
    expected_string = check["expected_string"]['S']
    
    ec2_state = instance_metadata.get('State', {})
    state = ec2_state .get('Name')
    
    value_in_ins = state    
    # Check if the instance is in 'running' state
    if value_in_ins in expected_string:
        compliance_status = "Yes"    
    else:
        compliance_status = "No"
    print_compliance_status(compliance_status, expected_string, value_in_ins)    
    set_saplense_status(instance_id, check['compliance_id']['S'], compliance_status, value_in_ins)    

###### END AWS Instance Running Status ######

###### Start AWS Instance auto_recovery Status ######
def check_ec2_auto_recovery_status(check, instance_id):
    global instance_metadata
    
    compliance_status = "Yes"
    expected_string = check["expected_string"]['S']
    maintenance_options = instance_metadata.get('MaintenanceOptions', {})
    ec2_auto_recovery = maintenance_options.get('AutoRecovery')

    value_in_ins = ec2_auto_recovery    
    # Check if the instance is in 'MaintenanceOptions': {'AutoRecovery': 'default'} state
    if value_in_ins in expected_string:
        compliance_status = "Yes"    
    else:
        compliance_status = "No"
    print_compliance_status(compliance_status, expected_string, value_in_ins)    
    set_saplense_status(instance_id, check['compliance_id']['S'], compliance_status, value_in_ins)    

###### End AWS Instance auto_recovery Status ######

###### Start AWS Instance IMDSv2_Compatibility ######
def check_imdsv2_compatibility(check, instance_id):
    global instance_metadata
    compliance_status = "Yes"
    expected_string = check["expected_string"]['S']
    
    metadata_options = instance_metadata.get('MetadataOptions', {})
    ec2_imdsv2 = metadata_options.get('HttpTokens')
    
    value_in_ins = ec2_imdsv2    
    # Check if the instance is in 'MaintenanceOptions': {'AutoRecovery': 'default'} state
    if value_in_ins in expected_string:
        compliance_status = "Yes"    
    else:
        compliance_status = "No"
    print_compliance_status(compliance_status, expected_string, value_in_ins)    
    set_saplense_status(instance_id, check['compliance_id']['S'], compliance_status, value_in_ins)
    
###### End AWS Instance IMDSv2_Compatibility ######

###### Start Describe EC2 instance Atributes ###### 
#https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/ec2/client/describe_instance_attribute.html
def describe_instance_attribute(instance_id, attribute_name):
    response = EC2Client.describe_instance_attribute(
        InstanceId=instance_id,
        Attribute=attribute_name
    )
    return response
###### End Describe EC2 instance Atributes ######     

###### Start Ec2 Stop Protection ######
def check_stop_protection(check, instance_id):
    
    compliance_status = "Yes"
    expected_string = check["expected_string"]['S']
    
    attribute_name = 'disableApiTermination'
    response = describe_instance_attribute(instance_id, attribute_name)
    value_in_ins = str(response['DisableApiTermination']['Value'])
    
    if value_in_ins.lower() in expected_string.lower() :
        compliance_status = "Yes"    
    else:
        compliance_status = "No"
    print_compliance_status(compliance_status, expected_string, value_in_ins)    
    set_saplense_status(instance_id, check['compliance_id']['S'], compliance_status, value_in_ins)  

###### End Ec2 Stop Protection ######

###### Start Ec2 Instance Type ######
def check_ec2_instance_type(check, instance_id):
    
    compliance_status = "Yes"
    expected_string = check["expected_string"]['S']

    attribute_name = 'instanceType'
    response = describe_instance_attribute(instance_id, attribute_name)
    value_in_ins = response['InstanceType']['Value']

    if value_in_ins in expected_string:
        compliance_status = "Yes"
    else:
        compliance_status = "No"
    print_compliance_status(compliance_status, expected_string, value_in_ins)
    set_saplense_status(instance_id, check['compliance_id']['S'], compliance_status, value_in_ins)
###### End Ec2 Instance Type ######

###### Start Ec2 Instance Initiated Shutdown Behavior ######
def check_ins_shut_bhv(check, instance_id):
    compliance_status = "Yes"
    expected_string = check["expected_string"]['S']

    attribute_name = 'instanceInitiatedShutdownBehavior'
    response = describe_instance_attribute(instance_id, attribute_name)
    value_in_ins = response['InstanceInitiatedShutdownBehavior']['Value']

    if value_in_ins in expected_string:
        compliance_status = "Yes"
    else:
        compliance_status = "No"
    print_compliance_status(compliance_status, expected_string, value_in_ins)
    set_saplense_status(instance_id, check['compliance_id']['S'], compliance_status, value_in_ins)
###### End Ec2 Instance Initiated Shutdown Behavior ######

###### Start Ec2 Termination Protection ######
def check_termination_protection(check, instance_id):
    compliance_status = "Yes"
    expected_string = check["expected_string"]['S']
    attribute_name = 'disableApiTermination'
    response = describe_instance_attribute(instance_id, attribute_name)
    value_in_ins = str(response['DisableApiTermination']['Value'])
    if value_in_ins.lower() in expected_string.lower():
        compliance_status = "Yes"
    else:
        compliance_status = "No"
    print_compliance_status(compliance_status, expected_string, value_in_ins)
    set_saplense_status(instance_id, check['compliance_id']['S'], compliance_status, value_in_ins)
###### End Ec2 Termination Protection #####

aws_processing_functions = {

    "InstanceAutoRecovery": check_ec2_auto_recovery_status,
    "StopProtection": check_stop_protection,
    "InstanceType": check_ec2_instance_type,
    "InstanceInitiatedShutdownBehavior": check_ins_shut_bhv,
    "DisableApiTermination": check_termination_protection,
    "InstanceRunningStatus": check_aws_instance_running_status,
    "IMDSv2_Compatibility": check_imdsv2_compatibility
    
}

#AWS Instance Status checks 
def process_aws_instance_status(check, instance_id):
    print ("\nInfo : processing AWS Instance Status Checks  check ID " + check['compliance_id']['S']  +" ===> " + check['check_description']['S'])
    
    resource_name = check["resource_name"]['S']
    if  resource_name in aws_processing_functions :
        aws_processing_function = aws_processing_functions[resource_name]
        aws_processing_function(check, instance_id)
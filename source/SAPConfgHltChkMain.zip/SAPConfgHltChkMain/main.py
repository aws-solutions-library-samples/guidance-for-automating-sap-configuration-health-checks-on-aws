"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""
import boto3
import json
import os.path
import csv


#Instance running status
#https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/ec2.html#EC2.Instance.state
#output : {'Code': 16, 'Name': 'running'}

def instance_running_status(instance_id):
  ec2 = boto3.client('ec2')
  try:
    response = ec2.describe_instances(InstanceIds=[instance_id])
    instance_state = response['Reservations'][0]['Instances'][0]['State']['Name']
    return instance_state
    
  except Exception as e:
    print(f"Error: {e}")
    return False
        
def lambda_handler(event, context):
  array_of_sap_instance_to_check = event['aws-sap-instance-ids']

  # invoke sap-robo-lens lambda asynchronously for the exisiting values 
  lambda_client = boto3.client('lambda')
  
  for value in array_of_sap_instance_to_check:
    print (value)
    #check if instance is running or not 
    instance_state = instance_running_status(value)
    if instance_state != 'running':
      print ("AWS instance " + value +" ---> not in running state")
      continue
    
    payload = {'sapinstanceID': value}
    try:
      # Invoke the second Lambda function asynchronously without waiting for its response.
      lambda_client.invoke(
          FunctionName="SAPConfgHltChkExe",
          InvocationType='Event',
          Payload=json.dumps(payload)
      )
      print(f"Invoked second Lambda function for checks: {value}")
    except Exception as e:
      print(f"Error invoking Lambda function: {e}")
    

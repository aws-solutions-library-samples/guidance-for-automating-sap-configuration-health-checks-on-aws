"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""
# This file contains functions that evaluate the checks to be executed.

from hanachecksgeneration import *
from paschecksgeneration import *
from ascschecksgeneration import *
from erschecksgeneration import *
from appchecksgeneration import *

# extract RHEL cluster resource id's when resource ID's are not passed via input csv
def extract_resource_ids(output):
    resource_ids = []

    # Split the output into lines for easier processing
    lines = output.strip().splitlines()

    for line in lines:
        # Trim any extra spaces at the start or end of the line
        line = line.strip()

        # Check for resource-ids after "Clone Set:"
        if "Clone Set:" in line:
            # Extract the resource-id by splitting after the "Clone Set:" string
            resource_id = line.split("Clone Set:")[1].split()[0]
            resource_ids.append(resource_id)

        # Check for resource-id before "ocf::heartbeat:aws-vpc-move-ip"
        elif "ocf::heartbeat:aws-vpc-move-ip" in line:
            # Extract the resource-id by splitting before the "ocf::heartbeat:aws-vpc-move-ip" string
            resource_id = line.split("(ocf::heartbeat:aws-vpc-move-ip)")[0].strip()
            # Remove any leading '*' or other symbols
            resource_id = resource_id.lstrip('* ').strip()
            resource_ids.append(resource_id)

    return resource_ids


def assign_resources(cluster_resources, ha_dr,instanceid):
    # Extract the variables from the dictionary
    SAPHanaTopology = cluster_resources.get('SAPHanaTopology', "").strip()
    SAPHana = cluster_resources.get('SAPHana', "").strip()
    OverlayIP = cluster_resources.get('OverlayIP', "").strip()

    # If ha_dr is 'yes' and cluster_resources is valid
    if ha_dr.lower() == 'yes':
        if SAPHanaTopology and SAPHana and OverlayIP:
            return SAPHanaTopology, SAPHana, OverlayIP

    # Check if any resource ID is missing and call extract_resource_ids if needed
    if not SAPHanaTopology or not SAPHana or not OverlayIP:
        output = execute_runcommand("crm_mon -1", instanceid)
        resource_ids = extract_resource_ids(output)
        
        # Assign the missing resource IDs
        if not SAPHanaTopology:
            SAPHanaTopology = resource_ids[0]
        if not SAPHana:
            SAPHana = resource_ids[1]
        if not OverlayIP:
            OverlayIP = resource_ids[2]

    return SAPHanaTopology, SAPHana, OverlayIP
    
# This Function is to process each row of the inventory are prepare metadata dict object
def prepare_metadata(instance_item, bucket):
    print ("Info : preparing the mera_data ")
    
    instance_no = int(instance_item[0].strip())
    instanceid = instance_item[1].strip()
    #check if instance ID exists in your AWS account - if the instance is is not avilable in the region no point of updating the dynamoDB table
    instance_avilable = check_instance_availability(instanceid)
    
    if instance_avilable:
        print (f"Info : Instance {instanceid} is available and running in your account.")
        # delete the all old checks if any
        delete_dynamo_items(instanceid, bucket)
        
    else:
        print (f"Error : Instance {instanceid} is not found in your account.")
        return False , False
    
    
    sap_application = instance_item[2].strip()
    type_of_system = instance_item[3].strip()
    sap_component = instance_item[4].strip()
    sid = (instance_item[5].strip()).upper()
    # CSV file chnages the instance number from 00 to 0 or 01 to 1
    sapinstanceno = "0" + instance_item[6].strip() if len(instance_item[6].strip()) == 1 else instance_item[6].strip()
    flag_val = instance_item[7].strip()
    ha_dr = instance_item[8].strip()
    # HA/DR = yes actualy repasent wheather pacemaker cluster set or not
    responsible_team = instance_item[9].strip()

    
    sh_sidadm = "sidadm=\"" + sid.lower() + "adm\";"
    sh_sap_instance_no = "sap_instance_no=\"" + sapinstanceno + "\";"
    #echo $DIR_EXECUTABLE -> /usr/sap/HDB/HDB10/exe
    #sh_py_location = "$DIR_EXECUTABLE/python_support/systemReplicationStatus.py"
    #sh_py_location = "py_location=\"/usr/sap/" + sid + "/HDB" + sapinstanceno + "/exe/python_support\";"
    #global_ini = "global_ini=\"/usr/sap/" + sid + "/SYS/global/hdb/custom/config/global.ini\";"
    #sues - sh_rsc_SAPHanaTopology = "$rsc_SAPHanaTopology=\"rsc_SAPHanaTopology_" + sid + "_HDB" + sapinstanceno + "\";"
    
    # Extract the variables from the dictionary
    SAPHanaTopology = SAPHana = OverlayIP = " "
    
    # this only for SAP HANA RHEL pacemaker
    if ha_dr.lower() == 'yes' and ("HANA_DB_Primary" in sap_component or "HANA_DB_Standby" in sap_component) :
        
        cluster_resources = instance_item[10].strip()

        #Check if cluster_resources is empty or None
        if not cluster_resources:
            data = {"SAPHanaTopology": " ", "SAPHana": " ", "OverlayIP": " "}
            cluster_resources = json.dumps(data)
        cluster_resources = json.loads(cluster_resources)
        #print(cluster_resources)
        SAPHanaTopology, SAPHana, OverlayIP = assign_resources(cluster_resources, ha_dr,instanceid)
    SAPHanaTopology = "rsc_SAPHanaTopology=\"" + SAPHanaTopology + "\";"
    SAPHana = "rsc_SAPHana=\"" + SAPHana + "\";"
    OverlayIP = "rsc_OverlayIP=\"" + OverlayIP + "\";"

    #default_plf = "default_plf=\"/usr/sap/" + sid + "/SYS/profile/DEFAULT.PFL\";"
    #instance_plf = "instance_plf=\"/usr/sap/" + sid + "/SYS/profile/" + sid + "_HDB" + sapinstanceno + "_" + sap_host_name + "\";"
    
    inventory_dict = {
    'instance_id': instanceid,
    'instance_no': instance_no, # AWS instance serial number 
    'sap_application': sap_application,
    'type_of_system': type_of_system,
    'sap_component': sap_component,
    'sid' :sid,
    'flag_val' : flag_val,
    'sapinstanceno':sapinstanceno,
    'ha_dr': ha_dr,
    'responsible_team': responsible_team,
    'sidadm': sh_sidadm,
    'sap_instance_no': sh_sap_instance_no,
    'SAPHanaTopology': SAPHanaTopology,
    'SAPHana': SAPHana,
    'OverlayIP' : OverlayIP,
    
    }
    
    #save meta data in to dynamo db table 
    save_dydb_meta_data(inventory_dict)
    
    return sap_component, inventory_dict

def prepare_health_checks(instance_item, bucket):
    
    # Determine the system type from Meta_Data
    sap_resource_type, meta_data = prepare_metadata(instance_item, bucket)
    
    if not sap_resource_type:
        return False
    print("Info : System Type is " + sap_resource_type)
    
    if sap_resource_type == 'HANA_DB_Primary':
        #Read Dynamo DB table where instance_id = input instance 
        checks_tmplt = get_template_from_s3(bucket, SAP_HANA_CHECKS_FILE)
        response = prepare_hana_health_checks_primary(meta_data['instance_id'],checks_tmplt,meta_data)
        
    elif sap_resource_type == 'HANA_DB_Standby':
        #prepare_hana_health_checks_standby()
        checks_tmplt = get_template_from_s3(bucket, SAP_HANA_CHECKS_FILE)
        response = prepare_hana_health_checks_primary(meta_data['instance_id'],checks_tmplt,meta_data)
        
    elif sap_resource_type == 'HANA_DB':
        checks_tmplt = get_template_from_s3(bucket, SAP_HANA_CHECKS_FILE)
        response = prepare_hana_health_checks(meta_data['instance_id'],checks_tmplt,meta_data)

    elif sap_resource_type == 'PAS':
        checks_tmplt = get_template_from_s3(bucket, SAP_ABAP_CHECKS_FILE)
        response = prepare_pas_health_checks(meta_data['instance_id'],checks_tmplt,meta_data)

    elif sap_resource_type == 'ASCS':
        checks_tmplt = get_template_from_s3(bucket, SAP_ABAP_CHECKS_FILE)
        response = prepare_ascs_health_checks(meta_data['instance_id'],checks_tmplt,meta_data)
        
    elif sap_resource_type == 'ERS':
        checks_tmplt = get_template_from_s3(bucket, SAP_ABAP_CHECKS_FILE)
        response = prepare_ers_health_checks(meta_data['instance_id'],checks_tmplt,meta_data)
        
    elif 'APP' in sap_resource_type:
        checks_tmplt = get_template_from_s3(bucket, SAP_ABAP_CHECKS_FILE)
        response = prepare_app_health_checks(meta_data['instance_id'],checks_tmplt,meta_data)
        
    else:
        print(f"Unknown SAP Component Type: {sap_resource_type}")
        response = f"Unknown SAP Component Type: {sap_resource_type}"

    return response

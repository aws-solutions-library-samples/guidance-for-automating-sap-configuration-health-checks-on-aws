# pylint: disable = C0103, R0902, W1203, C0301
"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""
#This file contains configuration parameters and utility functions for the project

import boto3
import csv
import io
import os
import json
import pprint
import datetime
import time
import tempfile
#configuration parameters
DYDB_TABLE = os.environ.get('dydb_chk_tbl')  
DYDB_TABLE_MDATA = os.environ.get('dydb_chk_tbl_mdata') 

# Commonly used objects
INVENTORY_FILE = "AWSSAPLensRoboInventory.csv"
INVENTORY_FILE_HEAD = ['sno', 'instance_id', 'sap_application', 'type_of_system', 'sap_component',
 'sid', 'sap_instance_no', 'flag', 'ha_dr', 'responsible_team','cluster_resources']
 
SAP_HANA_CHECKS_FILE = "inventory/SAPHANALensRoboHnCCheckTemplate.csv"
SAP_ABAP_CHECKS_FILE = "inventory/SAPABAPLensRoboHnCCheckTemplate.csv"


# A function to get the current regoin of the object  
REGION = boto3.session.Session().region_name
SSM_Client = boto3.client('ssm')

# A function to get the S3 client object    
def get_s3_client():
    return boto3.client("s3", region_name=REGION)

# A function to get the ec2 client object    
def get_ec2_client():
    return boto3.client('ec2')

# A function to get the dynamodb resource object
def get_dynamodb_resource():
    return boto3.resource("dynamodb", region_name=REGION)
    
# A function to get the dynamodb client object
def get_dynamodb_client():
    return boto3.client("dynamodb", region_name=REGION)

# A function to get the dynamodb table object
def get_dynamodb_table(table_name):
    return get_dynamodb_resource().Table(table_name)

# Function to replace empty strings with None
def replace_empty_string_with_none(value):
    return None if value == '' else value
    
# A function to read a csv file from S3 and return a list of dictionaries
def read_csv_from_s3(bucket, key):
    s3_client = get_s3_client()
    csv_file = s3_client.get_object(Bucket=bucket, Key=key)
    #csv_data = csv_file['Body'].read().decode('utf-8')
    #csv_reader = csv.DictReader(io.StringIO(csv_data))
    csv_data = csv_file['Body'].read().decode('ISO-8859-1').split('\n')
    csv_reader = csv.reader(csv_data, delimiter=',', quotechar='"')
    return iter(list(csv_reader)) # convert the list into an iterator

# Process the master list for each row in the instance list
def get_template_from_s3(bucket, template_file):
    print (f"Info : get the template {template_file} from S3 bucket ")

    checks_csv_reader = read_csv_from_s3(bucket, template_file)
        
    try:
        first_row = next(checks_csv_reader)
        #if not check_header(first_row): #pprint.pprint(next(checks_csv_reader)) # header fo the inventory csv file 
        #    print(f"Error : {template_file} Header row does not match expected format. Please us the original file from AWS Git")
        #    return False  # CSV file is not empty
    except StopIteration:
        print(f"Error : {template_file} is empty ")
        return f"Error : {template_file} is empty "# CSV file is empty
    
    except IndexError:
        print(f"Error: Index error occurred while reading {template_file}")
        return f"Error: Index error occurred while reading {template_file}"
    return checks_csv_reader
    
# Backup items to an S3 bucket as a CSV file.
def backup_items_to_s3(items, instance_id, bucket):
    s3 = get_s3_client()
    
    # Generate a unique backup file name based on the instance_id and current date/time
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
    backup_file_name = f"{instance_id}_{timestamp}.csv"
    
    # Define the CSV header based on the DynamoDB item structure
    header = list(items[0].keys())
    
    # Create a temporary file securely
    with tempfile.NamedTemporaryFile(delete=False, mode='w', newline='', suffix='.csv') as temp_csv:
        writer = csv.DictWriter(temp_csv, fieldnames=header)
        writer.writeheader()
        for item in items:
            writer.writerow(item)
        
        temp_csv.flush()
        temp_csv.close()

        temp_csv_file_name = temp_csv.name

    # Upload the CSV file to S3
    print(f"Info : Backing up all checks to S3 bucket {bucket} file name  {backup_file_name}")
    s3.upload_file(temp_csv_file_name, bucket, f'backup/{backup_file_name}')
    
    # Delete the temporary CSV file
    os.remove(temp_csv_file_name)  # Remove the local temporary file after uploading to S3


#    Delete all items in the DynamoDB table where the partition key matches the instance ID.
def delete_dynamo_items(instance_id,bucket):
    dynamodb = get_dynamodb_client()

    try:
        # Delete items in DynamoDB table
         # Scan DynamoDB table to get all items with the specified partition key
        response = dynamodb.scan(
            TableName=DYDB_TABLE,
            FilterExpression='instance_id = :value',
            ExpressionAttributeValues={':value': {'S': instance_id}}
        )
    
        items_to_delete = response.get('Items', [])    

        # Backup items to S3
        backup_items_to_s3(items_to_delete, instance_id,bucket)
    
        # Delete each item
        for item in items_to_delete:
            if item['set_by']['S'] =='AWS': # delete checks that are created only by AWS 
                
                dynamodb.delete_item(
                    TableName= DYDB_TABLE,
                    Key={'instance_id': {'S': item['instance_id']['S']}, 'compliance_id': {'S': item['compliance_id']['S']}}
                )
            else:
                print(f"Info : Not deleting item {item['compliance_id']['S']} as it is not created by AWS")
                print(item)
        print(f"Info : old checks are deleted for  {instance_id} in Dynamo DB Table - {DYDB_TABLE}")
        
    except Exception as e:
        # Handle exceptions (e.g., table not found, insufficient permissions)
        print(f"Error : deleting DynamoDB items: {str(e)}")
        pass

def execute_runcommand(run_command,instanceid):
    
    print(" " + "Command to be executed ---> " + run_command  ) 
    
    client = SSM_Client

    response = client.send_command(
        InstanceIds=[instanceid],
        DocumentName='AWS-RunShellScript',
        Parameters={
            'commands': [
                # Simple test if a file exists
                run_command
            ]
        }
    )
    
    command_id = response['Command']['CommandId']
    
    #print (response)
    tries = 0
    output = 'False'
    while tries < 100:
        tries = tries + 1
        try:
            #time.sleep(0.1)  # some delay always required...
            #print(tries)
            result = client.get_command_invocation(
                CommandId=command_id,
                InstanceId=instanceid,
            )
            
            if result['Status'] == 'InProgress':
                #print ('InProgress')
                continue
            output = result['StandardOutputContent']
            break
        except client.exceptions.InvocationDoesNotExist:
            continue
    print ("Info: Command output : " + output.strip())
    return output.strip()


# Function to create DynamoDB item for a row in the master list
def save_htl_check_dydb(compliance_id, hana_metadata_dict, hlt_check_item):
    dynamodb = get_dynamodb_client()

    resource_category = hlt_check_item[2].strip()
    complexity = hlt_check_item[3].strip()
    type_of_check = hlt_check_item[4].strip()
    resource_name = hlt_check_item[5].strip()
    command = hlt_check_item[6].strip()
    pattern_string = replace_empty_string_with_none(hlt_check_item[7].strip())
    expected_string = replace_empty_string_with_none(hlt_check_item[8].strip())
    check_description = replace_empty_string_with_none(hlt_check_item[9].strip())
    recommendation = replace_empty_string_with_none(hlt_check_item[10].strip())
    set_by = replace_empty_string_with_none(hlt_check_item[11].strip())
    sap_lens_category = replace_empty_string_with_none(hlt_check_item[12].strip())
    sap_lens_topic = replace_empty_string_with_none(hlt_check_item[13].strip())
    sap_lens_bp = replace_empty_string_with_none(hlt_check_item[14].strip())
    sap_lens_bp_suggestion = replace_empty_string_with_none(hlt_check_item[15].strip())
    created_time = str(datetime.datetime.now()).strip()
    dt = datetime.datetime.now()
    compliance_status = "No"
    value_of_ins = None
    last_check_execution_time = None

    #print('Info : **** check number  ****', str(hlt_check_item[0]).strip())
    try:
        add_to_db = dynamodb.put_item(
            TableName=DYDB_TABLE,
            Item={
                'compliance_id': {'S': str(compliance_id)},
                'instance_id': {'S': str(hana_metadata_dict['instance_id'])},
                'sap_application': {'S': str(hana_metadata_dict['sap_application'])},
                'resource_category': {'S': str(resource_category)},
                'complexity': {'S': str(complexity)},
                'type_of_check': {'S': str(type_of_check)},
                'resource_name': {'S': str(resource_name)},
                'command': {'S': str(command)},
                'pattern_string': {'S': str(pattern_string)},
                'expected_string': {'S': str(expected_string)},
                'check_description': {'S': str(check_description)},
                'recommendation': {'S': str(recommendation)},
                'set_by': {'S': str(set_by)},
                'sap_lens_category': {'S': str(sap_lens_category)},
                'sap_lens_topic': {'S': str(sap_lens_topic)},
                'sap_lens_bp': {'S': str(sap_lens_bp)},
                'sap_lens_bp_suggestion': {'S': str(sap_lens_bp_suggestion)},
                'created_time': {'S': str(created_time)},
                'compliance_status': {'S': str(compliance_status)},
                'value_of_ins': {'S': str(value_of_ins)},
                'last_check_execution_time': {'S': str(last_check_execution_time)}
            })
    
        print(f'{compliance_id} - Successfully added the records to Dynamo DB')
        
    except Exception as e:
        print (f"Error : save to dydb {str(e)}  ")
        return f"Error : save to dydb {str(e)}  "
     
    return True

# Function to save the meta_data or inventory in dynamodb table 
def save_dydb_meta_data(inventory_dict):
    dynamodb = get_dynamodb_client()
    
    # Convert inventory_dict to DynamoDB Item format
    dynamodb_item = {
        'instance_id': {'S': inventory_dict['instance_id']},
        'instance_no': {'S': str(inventory_dict['instance_no'])},
        'sap_application': {'S': inventory_dict['sap_application']},
        'type_of_system': {'S': inventory_dict['type_of_system']},
        'sap_component': {'S': inventory_dict['sap_component']},
        'sid': {'S': inventory_dict['sid']},
        'flag_val': {'S': inventory_dict['flag_val']},
        'sapinstanceno': {'S': inventory_dict['sapinstanceno']},
        'ha_dr': {'S': str(inventory_dict['ha_dr'])},  # Assuming ha_dr is a string, convert to str if necessary
        'responsible_team': {'S': inventory_dict['responsible_team']}
    }

    try:
        add_to_db = dynamodb.put_item(
            TableName=DYDB_TABLE_MDATA,
            Item=dynamodb_item
        )
        print(f'Successfully added the meta data to Dynamo DB')
    except Exception as e:
        print (f"Error : meta data save to dydb {str(e)}  ")
        raise e

# Function to get command for Meta_Data resource name
def get_command_for_meta_data(resource_name, inventory_dict):
    if "sap_application" in resource_name:
        return inventory_dict['sap_application'] 
    elif "type_of_system" in resource_name:
        return inventory_dict['type_of_system']  
    elif "sid" in resource_name:
        return inventory_dict['sid']  
    elif "sap_instance_no" in resource_name:
        return inventory_dict['sapinstanceno']  
    #elif "sap_host_name" in resource_name:
        #return inventory_dict['sap_host_name']  
    elif "sap_component" in resource_name:
        return inventory_dict['sap_component']  
    elif "responsible_team" in resource_name:
        return inventory_dict['responsible_team']
    elif "ha_dr" in resource_name:
        return inventory_dict['ha_dr']     

# get item from DYDB_TABLE from 
def get_item(instance_id, compliance_id):
    dynamodb = get_dynamodb_client()
    compliance_id = str(compliance_id)
    try:
        response = dynamodb.query(
            TableName=DYDB_TABLE,
            KeyConditionExpression='instance_id = :instance_id AND compliance_id = :compliance_id',
            ExpressionAttributeValues={
                ':instance_id': {'S': instance_id},
                ':compliance_id': {'S': compliance_id}
            }
        )
        
        items = response.get('Items', [])
        return items
    except Exception as e:
        print(f"Error get_checks_from_dynamo : {e}")
        
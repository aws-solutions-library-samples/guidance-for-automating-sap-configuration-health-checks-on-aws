"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""
# This file contains the main lambda function for the project
import json
import botocore
import datetime
from checkevaluator import *

# Main Lambda function
def lambda_handler(event, context):
    
    try:
        bucket = event['Records'][0]['s3']['bucket']['name']
        key = event['Records'][0]['s3']['object']['key']

        if validate_S3_inventory_event(bucket, key ):
            instance_list_csv_reader = read_csv_from_s3(bucket, key)
            try:
                first_row = next(instance_list_csv_reader)
                if not check_header(first_row): 
                    print(f"Error : {INVENTORY_FILE} Header row does not match expected format. Please us the original file from AWS Git")
                    return f"Error : {INVENTORY_FILE} Header row does not match expected format. Please us the original file from AWS Git"  # CSV file is not empty
            except StopIteration:
                print(f"Error : {INVENTORY_FILE} is empty ")
                return f"Error : {INVENTORY_FILE} is empty "# CSV file is empty
            for instance_item in instance_list_csv_reader:
                flag_val = instance_item[7] #flag column is the 8th column (index 4); chnage if position of falg chnages in inventory csv
                
                if flag_val.lower() == 'yes':
                    response = prepare_health_checks (instance_item, bucket)
                else:
                    print(f"Warning : {instance_item[2]} {instance_item[3]} {instance_item[4]} {instance_item[1]} Checks will not be created or updated while the flag is set to 'No'.")
        else:
            print(f"Error : Enter the correct Inventory file with name - {INVENTORY_FILE}")
            return f"Error : Enter the correct Inventory file with name - {INVENTORY_FILE}"
    except IndexError:
        print("Error: Index out of range while iterating over checks_tmplt")
        pass
    except Exception as e:
        print(str(e))
        return str(e)

    return {
        'statusCode': 200,
        'body': json.dumps('CSV to DynamoDB success')
    }

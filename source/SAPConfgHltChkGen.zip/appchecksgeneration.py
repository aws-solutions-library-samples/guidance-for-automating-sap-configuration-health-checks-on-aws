# pylint: disable = C0103, R0902, W1203, C0301
"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""
#This file comprises building meta-data and preparing health checks functions for the project
from validations import *
def prepare_app_checks(instance_id, check_item, app_metadata_dict):
    
    print ("Info : preparing the health checks commands  ")
    # header of app template -> 
    # 0-compliance_id 1-sap_component 2-resource_category 3-complexity 4-type_of_check	5-resource_name	
    # 6-command	7-pattern_string 8-expected_string 9-check_description	10-recommendation 11-set_by	sap_lens_category	
    # sap_lens_topic	sap_lens_bp	sap_lens_bp_suggestion
    type_of_check = check_item[4].strip()
    resource_name = check_item[5].strip()
    command = check_item[6].strip()
    # expected_string will be updated for some of the checks to match what is in the instance 
    #- like saphost - /app/data/<SID> to place SID whatever can be automatically update for customer 
    if type_of_check in "API":
        return check_item
    # Build command based on resource name
    # Meta_Data ----> this section need to be removed 
    if "Meta_Data" in type_of_check:
        #for the Mater Metadata that is coming from customer i form of inventory file the data will be fillied in column 'command' and 'expected_string'
        command = get_command_for_meta_data(resource_name, app_metadata_dict)
        # expected_string
        if command is None:
            command = " "
        check_item[6] = check_item[8] = command
        print("Meta Data : " + str(command))
    else:
        command = "sid="+app_metadata_dict['sid']+";" + app_metadata_dict['sidadm'] + app_metadata_dict['sap_instance_no'] + check_item[6].strip() 
        print("command : " + check_item[6])
    check_item[6] = command 
    return check_item
    
# function to generate primary application server checks 
def prepare_app_health_checks(instance_id,checks_tmplt, meta_data) :
    compliance_id = 100000
    try:
        for check in checks_tmplt:
            if  "app" in check[1] or check[1] == "general" or check[1] == "Meta_Data":    
                compliance_id += 1
                print (f"\n====Info : ABAP APP checks category - {check[2]} ====")
                hlt_check_item =  prepare_app_checks(instance_id, check, meta_data)
                response = save_htl_check_dydb(compliance_id,meta_data, hlt_check_item)
    except IndexError:
        print("Error: Index out of range while iterating over checks_tmplt")
        pass
    except Exception as e:
        print(f"Error Prepare PAS Health Checks : {e}")
        return f"Error : {e}"
    return response
###### End generate  app primary and standby  checks   ######

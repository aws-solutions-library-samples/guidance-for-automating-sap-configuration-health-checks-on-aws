# pylint: disable = C0103, R0902, W1203, C0301
"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""
#This file comprises building meta-data and preparing health checks functions for the project
from validations import *

def prepare_hana_primary_health_checks(instance_id, check_item, hana_metadata_dict):
    print ("Info : preparing the health checks commands  ")
    # header of hana template -> 
    # 0-compliance_id 1-sap_component 2-resource_category 3-complexity 4-type_of_check	5-resource_name	
    # 6-command	7-pattern_string 8-expected_string 9-check_description	10-recommendation 11-set_by	sap_lens_category	
    # sap_lens_topic	sap_lens_bp	sap_lens_bp_suggestion
    instanceid = hana_metadata_dict['instance_id']
    type_of_check = check_item[4].strip()
    resource_name = check_item[5].strip()
    command = check_item[6].strip()
    # expected_string will be updated for some of the checks to match what is in the instance 
    #- like saphost - /hana/data/<SID> to place SID whatever can be automatically update for customer 
    if type_of_check in "API":
        return check_item
    # Build command based on resource name
    # Meta_Data ----> this section need to be removed 
    if "Meta_Data" in type_of_check:
        #for the Mater Metadata that is coming from customer i form of inventory file the data will be fillied in column 'command' and 'expected_string'
        command = get_command_for_meta_data(resource_name, hana_metadata_dict)
        # expected_string
        check_item[6] = check_item[8] = command
        print("Meta Data : " + str(command))
    #systemReplicationStatus.py
    elif "systemReplicationStatus.py" in resource_name:
        command = hana_metadata_dict['sidadm'].strip() + check_item[6].strip()
        print("command : " + command)
        output = execute_runcommand(command, instanceid)
        if output.strip():
            check_item[8]  = output.strip()
    #Cluster_Configuration_SAPHanaTopology
    elif "Cluster_Configuration_SAPHanaTopology" in resource_name:
        command = hana_metadata_dict['rsc_SAPHanaTopology'].strip() + check_item[6].strip()
        print("command : " + command)
        output = execute_runcommand(command, instanceid)
        if output.strip():
            check_item[8]  = output.strip()
    # DEFAULT_Profile
    elif "DEFAULT_Profile" in resource_name:
        command = hana_metadata_dict['sidadm'] + hana_metadata_dict['sap_instance_no'] +check_item[6].strip()
        # execute the command and get the out put and update the expected string
        print("command : " + command)
        if "SAPSYSTEMNAME" in check_item[7]:
            # expected_string
            check_item[8] = hana_metadata_dict['sid']
        elif "SAPGLOBALHOST" in check_item[7]:
            # expected_string
            output = execute_runcommand(command, instanceid)
            if output.strip():
                check_item[8]  = output.strip()
    # INSTANCE_Profile
    elif "INSTANCE_Profile" in resource_name:
        command = hana_metadata_dict['sidadm'] + hana_metadata_dict['sap_instance_no'] +check_item[6].strip()
        print("command : " + command)
        if "INSTANCE_NAME" in check_item[7]:
            # expected_string
            check_item[8] = hana_metadata_dict['sid'] + hana_metadata_dict['sapinstanceno']    
    #global.ini
    elif "global.ini" in resource_name:
        command = hana_metadata_dict['sidadm'] + hana_metadata_dict['sap_instance_no'] +check_item[6].strip()
        print("command : " + command)
        if "basepath_datavolumes" in check_item[7]:
            # expected_string
            check_item[8] = "/hana/data/"+hana_metadata_dict['sid']
        elif "basepath_logvolumes" in check_item[7]:
            # expected_string
            check_item[8] = "/hana/log/"+hana_metadata_dict['sid']
    else:
        command = hana_metadata_dict['sidadm'] + hana_metadata_dict['sap_instance_no'] + check_item[6].strip() 
        print("command : " + check_item[6])
    check_item[6] = command 
    return check_item
    

# function to generate  hana primary and standby  checks 
def prepare_hana_health_checks_primary(instance_id,checks_tmplt, meta_data) :
    sno = str(meta_data['instance_no']).strip()
    compliance_id = int(sno) * 100000
    try:
        for check in checks_tmplt:
            compliance_id += 1
            print (f"\n====Info : Hana checks category - {check[2]} ====")
            hlt_check_item =  prepare_hana_primary_health_checks(instance_id, check, meta_data)
            response = save_htl_check_dydb(compliance_id,meta_data, hlt_check_item)
    except IndexError:
        print("Error: Index out of range while iterating over checks_tmplt")
        pass
    except Exception as e:
        print(f"Error : {e}")
        return f"Error : {e}"
    return response
###### End generate  hana primary and standby  checks   ######

# function to generate single instance hana checks 
def prepare_hana_health_checks(instance_id,checks_tmplt, meta_data) :
    print("Info : System Type is ========> HANA_DB")
    sno = str(meta_data['instance_no']).strip()
    compliance_id = int(sno) * 100000
    try:
        for check in checks_tmplt:
            response = " "
            if "SAP HANA Cluster" not in check[2] : # skipp all the cluster checks 
                compliance_id += 1
                print (f"\n====Info : Hana checks category - {check[2]} ====")
                hlt_check_item =  prepare_hana_primary_health_checks(instance_id, check, meta_data)
                response = save_htl_check_dydb(compliance_id,meta_data, hlt_check_item)
            else:
                print("Warning: Skipping cluster check  since no High Avilability")
    except IndexError:
        print("Error: Index out of range while iterating over checks_tmplt")
        pass
    except Exception as e:
        print(f"Error : {e}")
        return f"Error : {e}"
    return response
###### End Processing Checks  ######

# pylint: disable = C0103, R0902, W1203, C0301
"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""
#This file contains validation for enduser input functions for the project
from utilities import *

# A function to validate the inventory file name 
def validate_S3_inventory_event(bucket, key):
    
    if INVENTORY_FILE in key :
        print('Info : Bucket: ', bucket, 'Key :', key)
        print(f"Info : Inventory file name - {INVENTORY_FILE} avilable in S3")
        return True
    else:
        print(f"Warning : File uploaded to the s3://{bucket}/{key}")
        #print(f"Error : File name of the Inventory - {INVENTORY_FILE}")
        print(f"Error : Enter the correct Inventory file with name - {INVENTORY_FILE}")
        
# Function to check if Invntory file header matches expected column names
def check_header(header_row):
    return header_row == INVENTORY_FILE_HEAD

# check if the instance is avilable or not 
def check_instance_availability(instance_id):
    print("Info : Check the AWS Instance Availability ")
    
    ec2_client = get_ec2_client()

    try:
        # Describe the instance list to check if it exists
        response = ec2_client.describe_instances(InstanceIds=[instance_id])
        reservations = response['Reservations']
        # If the instance is found, return success
        if 'Reservations' in response and len(response['Reservations']) > 0:
            #check if the ec2 instance is running or not
            if reservations[0]['Instances'][0]['State']['Name'] == 'running':
                print(f"Info : Instance {instance_id} is running")
                return True
            else:
                print(f"Error : Instance {instance_id} is not running")
                return False
            
    except Exception as e:
        # If an error occurs, return an error message
        print(f"Error : {str(e)}")
        print((f"Error : No checks are prepared for instance : {instance_id} while instance is unavilable"))
        return False
    


